<?php
include 'Dbcon.php';
$otp=$_POST['otp'];
session_start();
$sotp=$_SESSION['otp'];

 if($otp == $sotp)
 {
	header('location:login.php');
 }
 else
 {
	 header('location:otp.php?error=1');
 }

?>