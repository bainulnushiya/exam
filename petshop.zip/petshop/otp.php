<!DOCTYPE HTML>
<head>
<title>Pet Shop</title>
<script src="checkc.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="script.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/nav-hover.js"></script>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
<script>
function validate()
{
if(document.getElementById('name').value=="")
{
alert("Enter name");
document.getElementById('name').focus();
return false;
}
if(document.getElementById('name').value!="")
{
var firstname = document.getElementById("name");
    var alpha = /^[a-zA-Z\s-, ]+$/; 
	if (!firstname.value.match(alpha)) {
        alert('only letters'); 
		document.getElementById('name').focus();      
        return false;
   }
}
if(document.getElementById('address').value=="")
{
alert("Enter address");
document.getElementById('address').focus();
return false;
}


if(document.getElementById('country').value==0)
{
alert("**select country**");
return false;
}
if(document.getElementById('email').value=="")
{
alert("**Enter email**");
document.getElementById('email').focus(); 
return false;
}
if(document.getElementById('email').value!="")
{
var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
    return false;
	}

}
if(document.getElementById('city').value=="")
{
alert("**Enter city**");
document.getElementById('city').focus(); 
return false;
}
if(document.getElementById('city').value!="")
{
var firstname = document.getElementById("city");
    var alpha = /^[a-zA-Z\s-, ]+$/; 
	if (!firstname.value.match(alpha)) {
        alert('only letters'); 
		document.getElementById('city').focus();      
        return false;
   }
}
if(document.getElementById('phone').value=="")
{
alert("**Enter phone**");
document.getElementById('phone').focus(); 
return false;
}
if(document.getElementById('phone').value!="")
{
var mob = /^[1-9]{1}[0-9]{9}$/;
 var   z=mob.test(document.getElementById('phone').value);
    if (z == false) {
        alert("Please enter valid mobile number.");
        document.getElementById('phone').focus();
        return false;
    }
}
if(document.getElementById('pwd').value=="")
{
alert("**Enter password**");
document.getElementById('pwd').focus(); 
return false;
}
return true;
}
</script>
<script>
function login()
{
if(document.getElementById('luname').value=="")
{
alert("**Enter username**");
document.getElementById('luname').focus(); 
return false;
}

if(document.getElementById('lpwd').value=="")
{
alert("**Enter password**");
document.getElementById('lpwd').focus(); 
return false;
}
return true;
}
</script>
</head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="header_top">
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form>
				    	<input type="text" value="Search for Products" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
				    </form>
			    </div>
			    <div class="login">
		   	   <span><a href="login.php"><img src="images/login.png" alt="" title="login"/></a></span>
		   </div>
	     
		     <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
		 </div>
			<div class="currency">
					
					 <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
   </div>
		   
		 <div class="clear"></div>
	   </div>
	 <div class="clear"></div>
   </div>
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		 <li><a href="index.php">Home</a></li>
    <li><a href="products.php">Products</a>
    
  </li>
  
  
  <li><a href="about.php">About</a></li>
   
  <li><a href="contact.php">Contact</a> </li>
  <div class="clear"></div>
</ul>
</div>

               
    	<div class="register_account">
    		<h3>OTP </h3>
   		  <form id="f1" method="post" action="otpvarify.php">
		  <td><div><input type="text" name="otp" onFocus="this.value = '';" id="otp" placeholder="otp" required></div>
	   			  
		   <div class="search"><div><input type="submit" value="Sumit" class="grey" onClick="return validate()"></div></div>
		    <p class="terms"></p>
		    <div class="clear"></div>
	      </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>
   
			
     </div>
    </div>
    
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
	<script src="js/validation.js"></script>
</body>
</html>

