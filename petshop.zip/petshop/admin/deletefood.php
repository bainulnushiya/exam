<?php
$id=$_GET['id'];
include('../Dbcon.php');
$qry="delete from food where FoodID=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:AddFood1.php');


?>