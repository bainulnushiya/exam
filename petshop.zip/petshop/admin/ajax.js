function getSub(id)
{
	
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState==4&& xmlhttp.status==200)
	{
		document.getElementById("sub").innerHTML=xmlhttp.responseText;
		
						
	}
	}
	xmlhttp.open("GET","findsub.php?id="+id,true);
	xmlhttp.send();
}