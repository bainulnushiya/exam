<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: large}
.style4 {
	color: #FFFFFF;
	font-weight: bold;
}
.style6 {font-size: large; color: #FFFFFF; font-weight: bold; }
-->
</style>
</head>

<body>
<div align="center">
<br />
<table width="935" height="90" border="0" style="border:solid">
  <tr>
    <td width="89" bgcolor="#333333"><span class="style6">Name&nbsp;</span></td>
    <td width="152" bgcolor="#333333"><span class="style6">Company	&nbsp;</span></td>
    <td width="89" bgcolor="#333333"><span class="style6">Email&nbsp;</span></td>
    <td width="119" bgcolor="#333333"><span class="style6">Address&nbsp;</span></td>
    <td width="124" bgcolor="#333333"><span class="style6">Country&nbsp;</span></td>
    <td width="105" bgcolor="#333333"><span class="style6">City&nbsp;</span></td>
    <td width="127" bgcolor="#333333"><span class="style6">Contact no&nbsp;</span></td>
    <td width="96" bgcolor="#333333">&nbsp;</td>
  </tr>
  <?php
  include '../Query.php';
  $qry="select * from tbl_register";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style1"><?php echo $row['name'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['cmpname'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['email'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['address'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['country'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['city'];?>&nbsp;</span></td>
    <td><span class="style1"><?php echo $row['contactno'];?>&nbsp;</span></td>
    <td><span class="style1"><a href="deleteuser.php?id=<?php echo $row['loginid'];?>">Delete</a>&nbsp;</span></td>
  </tr>
  <?php
  }
  ?>
</table>

</div>
</body>
</html>
