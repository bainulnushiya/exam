<?php
$id=$_GET['id'];
include('../Dbcon.php');
$qry="delete from addproduct where AddProductID=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:AddProducts1.php');

?>