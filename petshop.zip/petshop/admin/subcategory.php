<script>
function validate()
{
	if(document.getElementById('cat').value==0)
	{
	alert("**select category**");
	return false;
	}
	if(document.getElementById('sub').value=="")
	{
	alert("please fill this field");
	document.getElementById('sub').focus();
	return false;
	}
return true;
}	
</script>	
<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: large}
.style2 {
	color: #000000;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<div align="center">
<br /><br />
<form method="post">
<table width="314" height="143">
  <tr>
    <td width="138"><span class="style1">Category&nbsp;</span></td>
    <td width="164"><span class="style1">
      <select name="cat" id="cat">
        <option value="0">---Select---</option>
        <?php
	include '../Query.php';
	$qry="select * from tbl_category";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
    </span></td>
  </tr>
  <tr>
    <td><span class="style1">Subcategory&nbsp;</span></td>
    <td><span class="style1">
      <input type="text" name="sub" id="sub">
      &nbsp;</span></td>
  </tr>
  <tr>
    <td colspan="2"><div align="center"><input type="submit" name="submit" value="Submit" onClick="return validate()"/></div></td>
    </tr>
</table>
</form>
<?php
if(isset($_POST['submit']))
{
extract($_POST);
$qry="insert into tbl_subcategory(catid,subcategory) values('$cat','$sub')";
setData($qry);
}
?>
<br /><br /><br />
<h1>View Subcategory</h1>
<form method="post">
<table width="400" height="70" style="border:solid">
  <tr>
    <td bgcolor="#CCCCCC"><span class="style2 style1">
      <input type="submit" name="delete" value="Delete">
      &nbsp;</span></td>
    <td bgcolor="#CCCCCC"><span class="style2 style1">Category&nbsp;</span></td>
    <td bgcolor="#CCCCCC"><span class="style2 style1">Subcategory&nbsp;</span></td>
  </tr>
  <?php
  $qry="select * from tbl_subcategory,tbl_category where tbl_subcategory.catid=tbl_category.catid";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style2 style1">
      <input type="checkbox" name="ch[]" value="<?php echo $row[0];?>" />
      &nbsp;</span></td>
    <td><span class="style2 style1"><?php echo $row['category'];?>&nbsp;</span></td>
    <td><span class="style2 style1"><?php echo $row['subcategory'];?>&nbsp;</span></td>
  </tr>
  <?php
  }
  ?>
</table>
</form>
<?php
if(isset($_POST['delete']))
{
extract($_POST);
for($i=0;$i<count($ch);$i++)
{
extract($_POST);
$qry="delete from tbl_subcategory where subcatid='$ch[$i]'";
setData($qry);
}
}
?>
</div>
</body>
</html>
