<?php include('header.php');
	include('../Dbcon.php');
	$obj=new Dbcon;
	$qry="select * from food";
	$res=$obj->submitQuery($qry);

?>
<div align="center">
<table width="229" height="47">
  <tr><th>Id</th><th>Productname</th><th>Amount</th><th>ProductImage</th></tr>

</div>
<?php
while($row=mysqli_fetch_array($res))
{
	echo "<tr><td>".$row[0]."</td>
	
	<td>".$row[3]."</td>
	<td>".$row[4]."</td>
	
	<td><img width='100px' height='100px' src='../petfood/".$row[5]."'/></td>
	<td><a href='deletefood.php?id=".$row[0]."'>Delete</a>	</td></tr>";
}

?>
</table>
<?php include('footer.php');?>