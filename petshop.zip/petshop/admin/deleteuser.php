<?php
$id=$_REQUEST['id'];
include '../Query.php';
$qry="delete from tbl_register where loginid='$id'";
setData($qry);
$qry="delete from tbl_login where loginid='$id'";
setData($qry);
echo "<script>window.onload=function(){alert('Deleted....!');window.location='viewusers.php';}</script>";
?>