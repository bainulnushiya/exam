<?php
$id=$_REQUEST['id'];
include '../Query.php';
function getRandomWord($len = 7) {
    $word = array_merge(range('0', '9'), range('A', 'Z'));
    shuffle($word);
    return substr(implode($word), 0, $len);
}

$orderno = getRandomWord();
$qry="update tbl_sale set orderno='$orderno',status='accept' where saleid='$id'";
setData($qry);
echo "<script>window.onload=function(){alert('Accepted....!');window.location='userads.php';}</script>";
?>