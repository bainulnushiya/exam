<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style5 {color: #FFFFFF; font-weight: bold; font-size: large; }
.style6 {font-size: large}
-->
</style>
</head>

<body>
<br />
<div align="center">
<h1>Feedbacks</h1>
<br />
<table width="484" height="81" border="0" style="border:solid">
  <tr>
    <td bgcolor="#333333"><span class="style5">Feedback</span></td>
    <td bgcolor="#333333"><span class="style5">Posted By</span></td>
  </tr>
  <?php
  include '../Query.php';
  $qry="select * from tbl_feedback,tbl_register where tbl_feedback.userid=tbl_register.regid";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style6"><?php echo $row['feedback'];?>&nbsp;</span></td>
    <td><span class="style6"><?php echo $row['name'];?>&nbsp;</span></td>
  </tr>
  <?php
 }
 ?>
</table>

</div>
</body>
</html>
