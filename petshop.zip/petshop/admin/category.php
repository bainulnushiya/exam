
<?php 
if(isset($_POST['submit']))
{
	extract($_POST);
	include('../Query.php');
	$qry="insert into tbl_category(category)values('$Name')";
	setData($qry);
	header('location:category.php');
}
?>

<?php include('header.php');?>
<script>
function validate()
{
	if(document.getElementById('Name').value=="")
	{
		alert("Enter the field");
		document.getElementById('Name').focus();
		return false;
	}
	if(document.getElementById('Name').value!="")
	{
		var Name = document.getElementById("Name");
   		var alpha = /^[a-zA-Z\s-, ]+$/; 
		if (!Name.value.match(alpha)) 
		{
        	alert('only letters'); 
			document.getElementById('Name').focus();      
        	return false;
  		}
	}
  return true;
}   
</script>
<div align="center">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<h1> Category </h1>
 <tr>
    <td><div align="center"><strong>Name</strong>
      <label>
        <label>

      </label>
        <input type="text" name="Name" id="Name">
    </div></td>
    <td></label>
      <p>
        <label>
        <input type="submit" name="submit" id="ADD" value="ADD" onclick="return validate()"  />
        </label>
        <label></label>
      </p></td>
  </tr>
   <tr>
    <td colspan="2"><a href="category.php?action=save">view categories</a></td>
    </tr>
</form>
<br><br>
<div>
<?php
if(isset($_GET['action']))
{
?>
<table width="400" border="1" style="border:solid">
  <tr>
    <td><input type="submit"  name="delete" value="Delete" >&nbsp;</td>
    <td>Category&nbsp;</td>
  </tr>
  <?php
  include('../Query.php');
  $qry="select * from tbl_category";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo $row[1];?>&nbsp;</td>
  </tr>
  <?php
  }
  ?>
</table>

</div>
<?php
}
?>
</div>
<?php include('footer.php'); ?>