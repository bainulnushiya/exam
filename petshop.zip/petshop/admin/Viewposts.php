<?php 


if(isset($_POST['submit']))
{
	extract($_POST);
	include('../Dbcon.php');
	$obj=new Dbcon;
	$qry="insert into post(Rate,Status,Discribtion,Image,OrderStatus,OrderNo,PostedDate)values('$Rate','$Status','$Discribtion','$Image','$OrderStatus','$Orderno:','$PostedDate')";
	$obj->submitQuery($qry);
}
else
{

?>
<?php include('header.php');?>
<div align="center">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
<h1>  Posts </h1>
<table width="367" border="0">
  <tr>
    <td width="65">Rate</td>
    <td width="286"><form name="form1" method="post" action="">
      <label>
        <input type="text" name="Rate" id="Rate">
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Status</td>
    <td><form name="form2" method="post" action="">
      <label>
        <input type="text" name="Status" id="Status">
        </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Discribtion</td>
    <td><form name="form3" method="post" action="">
      <label>
      <textarea name="Discribtion" id="Discribtion" cols="45" rows="5"></textarea>
      </label>
    </form>    </td>
  </tr>
  <tr>
    <td>Image</td>
    <td><form name="form4" method="post" action="">
      <label><input type="file" name="ProductImage" id="ProductImage"></label>
    </form>    </td>
  </tr>
  <tr>
    <td>OrderStatus</td>
    <td><form name="form5" method="post" action="">
      <label>
      <input type="radio" name="radio" id="OrderStatus" value="OrderStatus">
      Deliverd</label>
      <label>
      <input type="radio" name="radio" id="OrderStatus2" value="OrderStatus">
      NotDeliverd</label>
    </form>    </td>
  </tr>
  <tr>
    <td>Orderno:</td>
    <td><form name="form6" method="post" action="">
      <label>
      <input type="text" name="Orderno:" id="Orderno:">
      </label>
    </form>    </td>
  </tr>
  <tr>
    <td height="43">PostedDate</td>
    <td><form name="form7" method="post" action="">
      <label>
      <input type="text" name="PostedDate" id="PostedDate">
      </label>
    </form>    </td>
  </tr>
</table>
 <tr>
    <td colspan="2"><div align="center">
      <label>
      <input type="submit" name="submit" id="submit" value="Accept" onclick="return validate()"/>
      </label>
    </div></td>
    </tr>
    <tr>
    <td colspan="2"><a href="viewposts.php">view posts</a></td>
    </tr>
     </tr>
   
    </form>
</div>
<?php include('footer.php');}?>