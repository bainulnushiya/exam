<?php include('header.php');?>
<div align="center">
<form action="#" method="get">
<h1> Accessorie </h1>
  <tr>
    <td><div align="center"><strong>Accessorie:</strong> 
      <label>
      <label>
        <select name="Accessorie" id="Accessorie">
          <option value="0">--select--</option>
          <option value="Pets Food">Pets Food</option>
          <option value="Carts">Carts</option>
          <option value="toa">Aquarium</option>
          <option value="toa">Others</option>
        </select>
      </label>
    </div></td>
    <td></label>
      <p>
        <label>
        <input type="submit" name="Add" id="Add" value="Add" />
        </label>
        <label>
         <input type="submit" name="Delete" id="Delete" value="Delete" />
        </label>
      </p></td>
  </tr>
  <tr>
    <td width="112" scope="col"><div align="center"></div></td>
    <td width="153" scope="col"><label><strong>Rate:</strong>
        <input type="text" name="name" id="name" />
          </label></td>
  </tr>
  <tr>
    <td colspan="2"><div align="center">
      <label>
      <input type="submit" name="submit" id="submit" value="Submit" onclick="return validate()"/>
      </label>
    </div></td>
    </tr>
   
</form>
</div>
<?php include('footer.php');?>