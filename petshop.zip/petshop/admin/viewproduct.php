<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style8 {color: #FFFFFF; font-weight: bold; font-size: large; }
.style11 {color: #000000}
-->
</style>
</head>

<body>
<div align="center">
<table width="1084" border="0" style="border:solid">
  <tr>
    <td width="132" height="46" bgcolor="#333333"><span class="style8">Category&nbsp;</span></td>
    <td width="139" bgcolor="#333333"><span class="style8">Subcategory&nbsp;</span></td>
    <td width="103" bgcolor="#333333"><span class="style8">Title&nbsp;</span></td>
    <td width="235" bgcolor="#333333"><span class="style8">Description&nbsp;</span></td>
    <td width="101" bgcolor="#333333"><span class="style8">Quantity&nbsp;</span></td>
    <td width="107" bgcolor="#333333"><span class="style8">Rate&nbsp;</span></td>
    <td width="134" bgcolor="#333333"><span class="style8">Image&nbsp;</span></td>
    <td width="83" bgcolor="#333333">&nbsp;</td>
    <td width="80" bgcolor="#333333">&nbsp;</td>
  </tr>
  <?php
  include '../Query.php';
  $qry="select * from tbl_product,tbl_category,tbl_subcategory where tbl_product.catid=tbl_category.catid and tbl_product.subcatid=tbl_subcategory.subcatid and tbl_category.catid=tbl_subcategory.catid";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style11"><?php echo $row['category'];?>&nbsp;</span></td>
    <td><span class="style11"><?php echo $row['subcategory'];?>&nbsp;</span></td>
    <td><span class="style11"><?php echo $row['title'];?>&nbsp;</span></td>
    <td><span class="style11"><?php echo $row['description'];?>&nbsp;</span></td>
    <td><span class="style11"><?php echo $row['quantity'];?>&nbsp;</span></td>
    <td><span class="style11"><?php echo $row['rate'];?>&nbsp;</span></td>
    <td><span class="style11"><img src="../upload/<?php echo $row['image'];?>" width="100px" height="100px" />&nbsp;</span></td>
    <td><span class="style11"><a href="editproduct.php?id=<?php echo $row[0];?>">Edit</a>&nbsp;</span></td>
    <td><span class="style11"><a href="deleteproduct.php?id=<?php echo $row[0];?>">Delete</a>&nbsp;</span></td>
  </tr>
  <?php
  }
  ?>
</table>

</div>
</body>
</html>
