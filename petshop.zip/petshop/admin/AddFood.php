<?php 


if(isset($_POST['submit']))
{
	extract($_POST);
	$fname=$_FILES['ProductImage']['name'];
	if(file_exists($fname))
	{
		$t=date('His');
		$fname=$t.$fname;
		
	}
	move_uploaded_file($_FILES['ProductImage']['tmp_name'],"../petfood/".$fname);
	include('../Dbcon.php');
	$obj=new Dbcon;
	$qry="insert into food(Productname,Amount,ProductImage)values('$ProductName','$Amount','$fname')";
	$obj->submitQuery($qry);
}
else
{

?>

<?php include('header.php');?>
<div align="center">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
<h1> Add Food </h1>
<table width="341" border="0">
  <tr>
    <td width="170">Product Name</td>
    <td width="155"><input type="text" name="ProductName" id="ProductName"></td>
  </tr>
  <tr>
    <td>Category</td>
    <td>
    <label>
    <select name="Category" id="Category">
          <option value="0">--select--</option>
          <option value="Dogs">Dogs</option>
          <option value="Cats">Cats</option>
          <option value="Fishes">Fishes</option>
          <option value="Others">Others</option>
        </select>
      </label>
      </select></td>
  </tr>
  <tr>
    <td>Amount</td>
    <td><input type="text" name="Amount" id="Amount"></td>
  </tr>
  <tr>
    <td height="101">Product Image</td>
    <td><input type="file" name="ProductImage" id="ProductImage"></td>
  </tr>
   <tr>
    <td colspan="2"><div align="center">
      <p>
        <label>
          <input type="submit" name="submit" id="submit" value="Submit" onclick="return validate()"/>
        </label>
      </p>
      <p>
      <div align="right">
       <tr>
    <td colspan="2"><a href="AddFood1.php">view Add food</a></td>
    </tr>
      </div>
      </p>
      
    </div></td>
    </tr>
</table>
</form>
</div>
<?php include('footer.php'); }?>