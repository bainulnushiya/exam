<?php include('header.php');
	include('../Dbcon.php');
	$obj=new Dbcon;
	$qry="select * from petcategory";
	$res=$obj->submitQuery($qry);




?>

<div align="center">
<table width="229" height="47">
  <tr><th>Id</th><th>Name</th></tr>



</div>
<?php
while($row=mysqli_fetch_array($res))
{
	echo "<tr><td>".$row[0]."</td>
	<td>".$row[1]."</td>
	<td><a href='deletecategory.php?id=".$row[0]."'>Delete</a>	</td></tr>";
}

?>
</table>
<?php include('footer.php');?>