<?php include('header.php');?>
  <li class="active"><a href="index.php">Home</a></li>
    <li><a href="Category.php">Category</a></li>
    <li><a href="feedback.php">Feedback</a></li>
    <li><a href="Accessory.php">Accessory</a></li>
    <li><a href="Posts.php">Posts</a></li>
    <li><a href="Food.php">Food</a></li>
  </ul>
<?php include('footer.php');?>
