<script>
function validate()
{
	if(document.getElementById('cat').value==0)
	{
	alert("**select category**");
	return false;
	}
	if(document.getElementById('sub').value==0)
	{
	alert("**select subcategory**");
	return false;
	}
	if(document.getElementById('title').value=="")
	{
	alert("please fill this field");
	document.getElementById('title').focus();
	return false;
	}
	if(document.getElementById('descr').value=="")
	{
	alert("please fill this field");
	document.getElementById('descr').focus();
	return false;
	}
	if(document.getElementById('qty').value=="")
	{
    alert("quantity must be filled out");
	document.getElementById('qty').focus();
    return false;
	}
	if(document.getElementById('rate').value=="")
	{
    alert("Rate must be filled out");
	document.getElementById('rate').focus();
    return false;
	}
return true;
}
</script>
<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="ajax.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style5 {font-size: large; font-weight: bold; color: #000000; }
.style6 {color: #000000}
-->
</style>
</head>

<body>
<div align="center">
<h1>Add Products</h1>
<form id="f1" method="post" enctype="multipart/form-data">
<table width="421" height="370" border="0">
  <tr>
    <td width="183"><span class="style5">Category&nbsp;</span></td>
    <td width="228"><span class="style5">
      <select name="cat" id="cat" onChange="getSub(this.value)">
        <option value="0">---Select---</option>
        <?php
    include '../Query.php';
	$qry="select * from tbl_category";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
      &nbsp;</span></td>
  </tr>
  <tr>
    <td colspan="2"><div id="sub"><span class="style6"></span></div></td>
  </tr>
  <tr>
    <td><span class="style5">Title&nbsp;</span></td>
    <td><span class="style5">
      <input type="text" name="title" id="title"/>
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style5">Description</span></td>
    <td><span class="style5">
      <textarea name="descr" id="descr"></textarea>
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style5">Quantity&nbsp;</span></td>
    <td><span class="style5">
      <input type="number" name="qty" id="qty" min="1" maxlength="100" />
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style5">Rate&nbsp;</span></td>
    <td><span class="style5">
      <input type="text" name="rate" id="rate" />
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style5">Image&nbsp;</span></td>
    <td><span class="style5">
      <input type="file" name="image" id="image" />
      &nbsp;</span></td>
  </tr>
  <tr>
    <td colspan="2"><div align="center" class="style5"><input type="submit" name="submit" value="Submit" onClick="return validate()"/></div></td>
    </tr>
</table>

</form>
</div>
<?php
if(isset($_POST['submit']))
{
$y=$_FILES['image']['name'];
$r=$_FILES['image']['tmp_name'];		
move_uploaded_file($r,"../upload/".$y);
extract($_POST);
$qry="insert into tbl_product(catid,subcatid,title,description,quantity,rate,image) values('$cat','$subcat','$title','$descr','$qty','$rate','$y')";
setData($qry);
echo "<script>window.onload=function(){alert('Product added....!');window.location='product.php';}</script>";
}
?>
</body>
</html>
