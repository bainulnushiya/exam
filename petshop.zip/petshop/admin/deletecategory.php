<?php
$id=$_GET['id'];
include('../Dbcon.php');
$qry="delete from petcategory where CategoryID=".$id;

$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:viewcategory.php');


?>