<?PHP
session_start();
include 'Query.php';
$uname=$_SESSION['uname'];
$lid=$_SESSION['lid'];
$sql="select * from tbl_login where username='$uname' and loginid='$lid'";
$res=setData($sql);
$row=mysqli_fetch_array($res);
echo "<script>window.onload=function(){alert('please note your password..... your password is....$row[2]');window.location='login.php';}</script>";
?>


