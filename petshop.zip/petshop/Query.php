	<?php
include 'Dbcon.php';
function  setData($qry)
{
$obj=new Dbcon();
$res=$obj->submitQuery($qry);
return $res;
}
function  update_Data($qry)
{
$obj=new Dbcon();
$res=$obj->updateQuery($qry);
}

?>