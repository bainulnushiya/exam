<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<script src="checkc.js"></script>
<style type="text/css">
<!--
.style1 {color: #FF0000}
-->
</style>
</head>

<body>
<?php
session_start();
$id=$_REQUEST['cid'];
if($id!= $_SESSION["code"]) 
{
?>
<div class="style1">Wrong captcha</div>
<input type="hidden" id="hid" value="1" />
<?php
}
else
{?>
<input type="hidden" id="hid" value="0" />
<?php }
?>
</body>
</html>
