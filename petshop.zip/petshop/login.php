<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<?php
session_start();

?>

 
 <!DOCTYPE HTML>
<head>
<title>Pet Shop</title>
<script src="checkc.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="script.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/nav-hover.js"></script>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
<script>
function validate()
{
if(document.getElementById('name').value=="")
{
alert("Enter name");
document.getElementById('name').focus();
return false;
}
if(document.getElementById('name').value!="")
{
var firstname = document.getElementById("name");
    var alpha = /^[a-zA-Z\s-, ]+$/; 
	if (!firstname.value.match(alpha)) {
        alert('only letters'); 
		document.getElementById('name').focus();      
        return false;
   }
}
if(document.getElementById('address').value=="")
{
alert("Enter address");
document.getElementById('address').focus();
return false;
}


if(document.getElementById('country').value==0)
{
alert("**select country**");
return false;
}
if(document.getElementById('email').value=="")
{
alert("**Enter email**");
document.getElementById('email').focus(); 
return false;
}
if(document.getElementById('email').value!="")
{
var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
    return false;
	}

}
if(document.getElementById('city').value=="")
{
alert("**Enter city**");
document.getElementById('city').focus(); 
return false;
}
if(document.getElementById('city').value!="")
{
var firstname = document.getElementById("city");
    var alpha = /^[a-zA-Z\s-, ]+$/; 
	if (!firstname.value.match(alpha)) {
        alert('only letters'); 
		document.getElementById('city').focus();      
        return false;
   }
}
if(document.getElementById('phone').value=="")
{
alert("**Enter phone**");
document.getElementById('phone').focus(); 
return false;
}
if(document.getElementById('phone').value!="")
{
var mob = /^[1-9]{1}[0-9]{9}$/;
 var   z=mob.test(document.getElementById('phone').value);
    if (z == false) {
        alert("Please enter valid mobile number.");
        document.getElementById('phone').focus();
        return false;
    }
}
if(document.getElementById('pwd').value=="")
{
alert("**Enter password**");
document.getElementById('pwd').focus(); 
return false;
}
return true;
}
</script>
<script>
function login()
{
if(document.getElementById('luname').value=="")
{
alert("**Enter username**");
document.getElementById('luname').focus(); 
return false;
}

if(document.getElementById('lpwd').value=="")
{
alert("**Enter password**");
document.getElementById('lpwd').focus(); 
return false;
}
return true;
}
</script>
</head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="header_top">
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form>
				    	<input type="text" value="Search for Products" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
				    </form>
			    </div>
			    <div class="login">
		   	   <span><a href="login.php"><img src="images/login.png" alt="" title="login"/></a></span>
		   </div>
	     
		     <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
		 </div>
			<div class="currency">
					
					 <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
   </div>
		   
		 <div class="clear"></div>
	   </div>
	 <div class="clear"></div>
   </div>
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		 <li><a href="index.php">Home</a></li>
    <li><a href="products.php">Products</a>
    
  </li>
  
  
  <li><a href="about.php">About</a></li>
   
  <li><a href="contact.php">Contact</a> </li>
  <div class="clear"></div>
</ul>
</div>
<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">
							
				
			</div>
			<div class="section group">
							
				
			</div>
		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		     	<div id="slideshow">
	
		    <span class="arrow previous"></span>
		    <span class="arrow next"></span>
		  </div>
	    </div>
	  <div class="clear"></div>
  </div>
 </div>
 <div class="main">
    <div class="content">
    	 <div class="login_panel">
        	<h3>Existing Customers</h3>
        	<p>Sign in with the form below.</p>
        	<form action="loginprocess.php" method="post" id="member">
        	  <input name="username" type="text" class="field" onFocus="this.value = '';" placeholder="Email" id="luname">
       	   <input name="password" type="password" class="field" id="lpwd" placeholder="Password">
                
                 <p class="note"> <table>
    
     <tr>
                           <td></td>
            <td id="imgparent"><font size="14px" color="#FF0000"><div id="imgdiv"><img id="img" src="captcha.php" /></div></font>
            <img id="reload" src="reload.png" /></td>
</tr>
                        <tr>
                            <td>Enter Image Text:</td>
                            <td><input id="captcha1" name="captcha" type="text" onBlur="checkcaptcha(this.value)"><div id="cc"></div></td>
                        </tr>
  
     </table>
                 </p>
           <div class="buttons"><div><input type="submit" class="grey" value="Sign In" name="submit" onClick="return login()" id="submit"></div></div><A href="forgot.php">FORGOT PASSWORD</A> </form>
                    </div>
    	<div class="register_account">
    		<h3>Register New Account</h3>
   		  <form id="f1" method="post" action="regprocess.php">
	   			   <table>
		   				<tbody><tr><td><div><input type="text" name="f_name" onFocus="this.value = '';" placeholder="name" id="name" onChange="fn()" onkeypress="return onlyAlphabets(event,this);"></div>
		    			<div><input type="text" name="cmpname"  placeholder="Pin code" id="cmpname" onChange="pincode()" onkeypress="javascript:return isNumber(event);"></div>
		    			<div>
		    			  <input type="text" name="email" onFocus="this.value = '';" placeholder="Email" id="email" onChange="efn()">
		    			</div>
		    			<div><input type="text" id="pwd" name="pwd" onFocus="this.value = '';" placeholder="Password" required></div>
		    			 </td>
		    			<td><div><input type="text" name="address" onFocus="this.value = '';" id="address" placeholder="address" required></div>
		    			<div><select name="country" onchange="getId(this.value);">
     <option value="">select country</option> 
     <?php
	 include 'Query.php';
		
	
     $query = "SELECT * FROM tbl_country";
     $results =setData($query);

     foreach ($results as $country) {
       ?>
       <option value="<?php echo $country["cid"]; ?>"> <?php echo $country["country"]; ?></option>

<?php
     }
     ?>
  </select>
	</div>
	
	
<div 
	<label for="contact-message"></label>
	<select name="city" id="city"  >
        <option value=" ">state</option>

     </select>
	 </div>		        
		                
		                <div>
						<p>Country Code + Phone Number</p>
		          	<input type="text" name="code" value="+91" class="code"> - <input type="text" id="phone" name="phone" value="" class="number" maxlength="10" title="must contain atleast 10 numbers" onkeypress="javascript:return isNumber(event)" onChange="phone();">
		          		
		          </div>		<div>
		                  
		    </tr> 
		    </tbody></table> 
		   <div class="search"><div><input type="submit" value="Create Account" class="grey" onClick="return validate()"></div></div>
		    <p class="terms"></p>
		    <div class="clear"></div>
	      </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">gfu[r]
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#"><span>Advanced Search</span></a></li>
						<li><a href="#">Orders and Returns</a></li>
						<li><a href="#"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="about.html">About Us</a></li>
						<li><a href="faq.html">Customer Service</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="contact.html"><span>Site Map</span></a></li>
						<li><a href="preview-2.html"><span>Search Terms</span></a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="contact.html">Sign In</a></li>
							<li><a href="index.html">View Cart</a></li>
							<li><a href="#">My Wishlist</a></li>
							<li><a href="#">Track My Order</a></li>
							<li><a href="faq.html">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-123-456789</span></li>
							<li><span>+00-123-000000</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			<div class="copy_right">
				<p>Compant Name © All rights Reseverd | Design by  <a href="http://w3layouts.com">W3Layouts</a> </p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<script src="js/jquery.js"></script>

<script>
function getId(val){
	alert( val);
  $.ajax({
    type: "POST",
    url: "getdata.php",
    data: "cid="+val,
    success: function(data){
      $("#city").html(data);

}
});
}
</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
	<script src="js/validation.js"></script>
</body>
</html>

