function checkcaptcha(id)
{
	
	if(window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if(xmlhttp.readyState==4&& xmlhttp.status==200)
	{
		document.getElementById("cc").innerHTML=xmlhttp.responseText;
		if(document.getElementById("hid").value==1)
		
		document.getElementById("submit").disabled=true;
		else
		document.getElementById("submit").disabled=false;
						
	}
	}
	xmlhttp.open("GET","findcap.php?cid="+id,true);
	xmlhttp.send();
}