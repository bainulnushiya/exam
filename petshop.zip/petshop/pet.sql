-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2015 at 02:50 PM
-- Server version: 5.5.36
-- PHP Version: 5.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pet`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `cartid` int(50) NOT NULL AUTO_INCREMENT,
  `userid` int(50) NOT NULL,
  `productid` int(50) NOT NULL,
  `saveddate` date NOT NULL,
  PRIMARY KEY (`cartid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartid`, `userid`, `productid`, `saveddate`) VALUES
(1, 6, 6, '2015-04-13'),
(2, 7, 15, '2015-04-14'),
(3, 7, 22, '2015-04-17'),
(4, 7, 4, '2015-04-17'),
(5, 7, 6, '2015-04-17'),
(6, 7, 5, '2015-04-17'),
(7, 5, 31, '2015-04-27'),
(8, 5, 23, '2015-04-27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catid`, `category`) VALUES
(1, 'Dog'),
(2, 'Cat'),
(3, 'Fish'),
(4, 'Birds');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE IF NOT EXISTS `tbl_contact` (
  `contactid` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenumber` bigint(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  PRIMARY KEY (`contactid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`contactid`, `name`, `email`, `phonenumber`, `subject`) VALUES
(1, 'xc', 'vxv', 1234567891, ' vbnv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE IF NOT EXISTS `tbl_feedback` (
  `feedbackid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `feedback` text NOT NULL,
  PRIMARY KEY (`feedbackid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`feedbackid`, `userid`, `feedback`) VALUES
(4, 4, 'hii petshop,\r\nhappy to join here :)'),
(6, 4, 'rduytfhggfuj\r\nihguygutgb\r\nhgyutgyuugvfttr'),
(21, 3, 'niceeeeeeeeeeeee'),
(22, 3, 'fdfdf'),
(9, 4, 'hii hellooooo'),
(16, 4, 'kjsdggvdfdfvsdhfsdbvxczbnvfdsafdsfdsvdsfv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `loginid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`loginid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`loginid`, `username`, `password`, `role`) VALUES
(5, 'admin', 'admin', 'admin'),
(6, 'anjujohn706@gmail.com', '123', 'user'),
(7, 'sudhishvijayan89@gmail.com', '12345', 'user'),
(14, 'sss@ff.com', '777', 'user'),
(15, 'sss@ff.com', 'sss', 'user'),
(16, 'gfhf@gmail.com', '12345', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `paymentid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `saleid` int(11) NOT NULL,
  `bank` varchar(20) NOT NULL,
  `ccno` varchar(20) NOT NULL,
  `ccname` varchar(20) NOT NULL,
  `expdate` varchar(20) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`paymentid`, `userid`, `saleid`, `bank`, `ccno`, `ccname`, `expdate`) VALUES
(1, 4, 4, 'SBI', 'fdf', '', ''),
(2, 4, 23, 'SBI', '21313', '21312321', '2015-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `productid` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` bigint(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productid`, `catid`, `subcatid`, `title`, `description`, `quantity`, `rate`, `image`) VALUES
(3, 1, 1, 'Dry Food', 'BLUE WildernessÂ® Grain Free Adult Dog Food', 40, 150, 'pPETNA-5173391_main_t300x300.jpg'),
(2, 1, 1, 'Dry food', ' \r\nYOU MIGHT ALSO LIKE\r\nBLUE Life Protection Formula Chicken & Brown Rice Healthy...\r\nBLUE Life Prot', 50, 200, 'pPETNA-5066967_main_t300x300.jpg'),
(4, 1, 1, 'Adult dog food', ' \r\nYOU MIGHT ALSO LIKE\r\nAuthority Adult Dog Food\r\nAuthority Adult Dog Food\r\n$24.99\r\nWellness Complet', 50, 300, 'pPETNA-1211063_main_t300x300.jpg'),
(5, 1, 1, 'PurinaÂ® ONEÂ® Natural Adult Dog Food', 'PurinaÂ® ONEÂ® Natural Adult Dog Food', 40, 200, 'pPETNA-5127459_main_t300x300.jpg'),
(9, 1, 1, 'Grain Free Natural Chicken & Potato Recipe Adult', 'Natural Chicken & Potato Recipe Adult dog food provides grain free natural ingredients perfectly bal', 6, 650, 'IB_K9_D_adt_NA_o_O_GF_chknPot_500_en.png'),
(8, 1, 1, 'Crafted Grain Free Herbed Chicken & Chickpeas Reci', 'We use thoughtfully sourced, authentic ingredients like natural chicken and chickpeas. These authent', 5, 600, 'IB_K9_D_adt_Crftd_o_O_GF_chknChckpea_500_en.png'),
(10, 1, 1, 'NUTROÂ® DOG FOOD', 'NUTROÂ® Dog Food gives your dog premium natural nutrition thatâ€™s tailored to their life stage, bre', 5, 850, 'natural-choice-dog-food62e8e1e1e2336b43910eff0100f'),
(21, 2, 4, 'Natural Balance Limited Ingredient Diets Green Pea', 'A proven Grain-Free Formula for cats and kittens with allergies based on our unique protein and carb', 10, 1400, '723633002325C.jpg'),
(22, 2, 4, 'Natural Balance Wild Pursuit Chicken, Turkey & Qua', 'Natural Balance Wild Pursuit formulas feature high protein, grain-free nutrition from diverse and ba', 10, 1900, '723633520416C.jpg'),
(23, 2, 4, 'Natural Balance Delectable Delights Adult Cat Food', 'It is important to make sure your feline companion gets enough nutrition to stay strong, healthy and', 8, 600, '723633532006C.jpg'),
(24, 2, 4, 'Natural Balance Platefulls Adult Cat Food', 'Natural Balance Platefulls Adult Cat Food contains a unique blend of flavors in a delicate tasty gra', 10, 1260, '723633531009C.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE IF NOT EXISTS `tbl_register` (
  `regid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `cmpname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `contactno` bigint(20) NOT NULL,
  `loginid` int(11) NOT NULL,
  PRIMARY KEY (`regid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`regid`, `name`, `cmpname`, `email`, `password`, `address`, `country`, `city`, `contactno`, `loginid`) VALUES
(3, 'anju', 'logic', 'anjujohn706@gmail.com', '123', 'an', 'IN', 'kottayam', 9823781234, 6),
(4, 'Sudhish', 'sudhish vijayan', 'sudhishvijayan89@gmail.com', '12345', 'Ahoormanakal house', 'IN', 'kottayam', 9876543212, 7),
(6, 'sam', 'sdasadasd', 'sdasdasd@gmail.com', 'password', 'fgfdsd', 'AT', 'kalam', 9876543323, 9),
(7, 'sam', 'dfssdf', 'fdhsd@gmail.com', '123456', 'aaaas', 'IN', 'City', 9876665654, 10),
(8, 'vhbnjhgfhg', 'ghgfhgfhgf', 'gfhf@gmail.com', '123456', 'ghgfh', 'AZ', 'koyyh', 9878765545, 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sale`
--

CREATE TABLE IF NOT EXISTS `tbl_sale` (
  `saleid` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `briefdesc` text NOT NULL,
  `detaildesc` text NOT NULL,
  `posted_date` date NOT NULL,
  `itemcount` int(11) NOT NULL,
  `rate` bigint(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `orderno` varchar(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`saleid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `tbl_sale`
--

INSERT INTO `tbl_sale` (`saleid`, `catid`, `subcatid`, `userid`, `briefdesc`, `detaildesc`, `posted_date`, `itemcount`, `rate`, `status`, `orderno`, `image`) VALUES
(6, 1, 9, 4, 'Name	Beagle\r\nOther names	English Beagle\r\nOrigin	Great Britain\r\nSize Type	Small dog breeds\r\nBreed Group	Hound dog breeds (AKC)\r\nLife span	11-15 years\r\nTemperament	Gentle, Intelligent, Even Tempered, Determined, Amiable, Excitable\r\nHeight	Male: 13â€“16 inches (33â€“41 cm)\r\nWeight	Male     22â€“25 lb (10â€“11 kg)\r\nFemale     20â€“23 lb (9â€“10 kg)\r\nColors	Tri-color, Chocolate Tri, White & Tan, Red & White, Brown & White, Lemon & White, Orange & White', 'Beagle, also known as "Beagles", one of the world dog is a breed is a hunting dog in the classification. Frequently ranked in the top ten of the most popular dogs in the United States, Japan, and welcome each year has been rising. Standard shape: the head was a large dome shape, large hazel-colored eyes, broad long-lop, muscular body and tail more coarse like mahi-like. Hair quality and hair color: a dense growth of short bristles, a coat of white, black and liver-colored hound color, white brown, white lemon.', '2015-04-07', 6, 14000, 'accept', 'B20SL9P', 'Beagle-3.jpg'),
(4, 1, 7, 4, 'Name	Labrador Retriever\r\nOther names	Lab\r\nOrigin	United Kingdom, Canada\r\nSize Type	Medium dog breeds\r\nBreed Group	Sporting dog breeds (AKC)\r\nLife span	10-13 years\r\nTemperament	Gentle, Intelligent, Good-tempered, Kind, Outgoing, Agile\r\nHeight	Male: 22â€“25 inches (56â€“62 cm)\r\nFemale: 21â€“24 inches (54â€“60 cm)\r\nWeight	Male: 30â€“36 kg\r\nFemale: 25â€“32 kg\r\nColors	Black, chocolate, or yellow (pale cream)', 'The Labrador Retriever is a strongly built, medium-sized, short, a dog with a sound, athletic, well-balanced conformation that enables it to operate as a hunting dog recovery, substance and soundness to hunt waterfowl or upland for long hours in difficult conditions, the character and quality to win in the ring, and the temperament to be a family companion. Physical features and mental characteristics should denote a dog bred to perform as an efficient Retriever of game with a stable temperament suitable for a variety of activities beyond the hunting environment.\r\n\r\nThe most distinctive features of the Labrador Retriever are its short dense coat, weatherproof, an "otter" tail, a clean-cut head with broad back skull and moderate stop, powerful jaws, and its "kind," friendly eyes, expressing character, intelligence and good temperament.\r\n\r\nAbove all, a Labrador Retriever must be well balanced, allowing it to move in the ring or work in the field with little or no effort. The typical Labrador possesses style and quality without over refinement, and substance without lumber or cloddiness. The Labrador is bred primarily as a gun dog work, structure and soundness are of great importance.', '2015-04-07', 10, 30000, 'accept', '3K29UP1', 'Labrador-Retriever-3.jpg'),
(5, 1, 8, 4, 'Name	German Shepherd Dog\r\nOther names	Alsatian, Berger Allemand , Deutscher SchÃ¤ferhund ,GSD , SchÃ¤ferhund\r\nOrigin	Germany\r\nSize Type	Large dog breeds\r\nBreed Group	Herding dog breeds (AKC)\r\nLife span	7-10 years\r\nTemperament	Gentle, Intelligent, Good-tempered, Kind, Outgoing, Agile\r\nHeight	Male: 24â€“26 inches (60â€“65 cm)\r\nFemale: 22â€“24 inches (55â€“60 cm)\r\nWeight	Male: 22â€“40 kg\r\nFemale: 22â€“40 kg\r\nColors	Most commonly tan with black saddle', 'Give the impression of a good German Shepherd is a strong, agile, well muscled, alert and energetic. Very smooth, very harmonious front and rear hindquarters. Body longer than tall, deep body, body outline of smooth curves rather than angles. The sturdy body rather than slender, muscular either rest or in motion, giving the impression that they are agile neither clumsy nor looks weak. The ideal German shepherd gives the impression that it is of good quality, with the noble sense of the unspeakable, but one will be able to tell the difference, made â€‹â€‹no mistake. Gender identity is very clear, depending on their gender, or seemed majestic look soft.', '2015-04-07', 10, 9000, 'accept', '5LRQ3T0', 'German-Shepherd-Dog-3.jpg'),
(7, 1, 10, 4, 'Name	Golden Retriever\r\nOther names	No\r\nOrigin	Great Britain\r\nSize Type	Large dog breeds\r\nBreed Group	Sporting dog breeds (AKC)\r\nLife span	10-13 years\r\nTemperament	Intelligent, Kind, Friendly, Confident, Reliable, Trustworthy\r\nHeight	Female: 21â€“23 inches (55â€“57 cm)\r\nMale: 23â€“24 inches (58â€“61 cm)\r\nWeight	Female: 24.8â€“29.6 kg\r\nMale: 29.3â€“35 kg\r\nColors	Golden, Dark Golden, Light Golden', 'Golden Retriever, both said, a strong, lively dog, solid, various parts of the body with the reasonable, neither too long nor clumsy legs, facial expressions friendly personality enthusiasm, alertness, self-confidence. Because it is a hunting dog, and in the the hardship work environment in order to demonstrate the nature and characteristics of.His overall appearance, balance, gait and purpose of the breeds body should be a separate part of more attention. Defects: any departure from the ideal description of the breed can be considered a fault and the severity of the defect is in contradiction with the purpose of the breeds or decided contrary to the extent and characteristics of the breed.', '2015-04-07', 10, 25000, 'accept', 'DF91VTS', 'Golden-Retriever-3.jpg'),
(8, 1, 11, 4, 'Name	Bulldog\r\nOther names	English Bulldog\r\nOrigin	England\r\nSize Type	Medium dog breeds\r\nBreed Group	Non-Sporting dog breeds (AKC)\r\nLife span	8-12 years\r\nTemperament	Friendly, Docile, Willful, Gregarious\r\nHeight	Female: 12â€“16 inches (31â€“40 cm)\r\nMale: 12â€“16 inches (31â€“40 cm)\r\nWeight	Female: 22â€“23 kg\r\nMale: 24â€“25 kg\r\nColors	Fawn, Red, Red & White, Fawn & White, Gray Brindle, Brindle & White', 'The perfect Bulldog must be of medium size and smooth coat; with heavy, thick-set, low-swung body, massive short-faced head, wide shoulders and sturdy limbs. The general appearance and attitude should suggest great stability, vigor and strength. The disposition should be equable and kind, resolute and courageous (not vicious or aggressive), and demeanor should be pacific and dignified. These attributes should be countenanced by the expression and behavior.', '2015-04-07', 9, 17000, 'accept', '6TYWNAC', 'Bulldog-3.jpg'),
(9, 1, 12, 4, 'Name	Dachshund\r\nOther names	Teckel, Weenie Dog, Sausage Dog, Bassotto, Worshond\r\nOrigin	Germany\r\nSize Type	Small dog breeds\r\nBreed Group	Hound dog breeds (AKC)\r\nLife span	12 -15 years\r\nTemperament	Clever, Courageous, Devoted, Lively, Playful, Stubborn\r\nHeight	8 - 9 inches\r\nWeight	16 - 32 pounds\r\nColors	Cream, Black, Red, Tan, Blue, Chocolate, Black & Tan, Chocolate & Cream', 'Dachshund is a short, long, canine. The name derives from German, meaning " badger dogs ". This breed was developed for the EP, tracking, and hunting badgers and other burrowing animal. Interestingly, although the word "Dachshund" is a German word, but it is not commonly used in Germany, the Germans often call it Dackel or Teckel.', '2015-04-07', 9, 6000, 'accept', 'BHAW10V', 'Dachshund-3.jpg'),
(16, 2, 20, 0, 'Color:	A spotted or ticked brown tabby pattern is dominant. All colors and patterns have been found, including points with or without markings.\r\nGrooming:	Minimal. Whether medium or long, coat does not mat.\r\nBest Home:	Great with all members of the family, including children.\r\nAccepted for Show:	By TICA on May 1, 1989.\r\nPersonality:	Playful, patient, attentive, masters tricks easily.\r\nAppearance:	Wedge-shaped head, high cheekbones, large oval almond eyes, brawny and athletic body, heavy boning, hind legs slightly longer than front and short tails 1" to 6" in length.', 'The American Bobtail is a short-tailed cat, with a medium to large frame. Its tail should be clearly visible above the back when the cat is alert, not exceeding the hock in length. The American Bobtail is an excellent example of breed development through natural selection -- a completely domestic cat with no wild strains in its background. Affectionate and gentle, this young American will soon capture your heart..', '2015-04-07', 3, 9000, 'accept', 'LMBR9E6', 'american_bobtail_longhair_new.JPG'),
(11, 1, 16, 4, 'Name	Rottweiler\r\nOther names	Rott, Rottie\r\nOrigin	Germany\r\nSize Type	Large dog breeds\r\nBreed Group	Working dog breeds (AKC)\r\nLife span	9 -10 years\r\nTemperament	Alert, Good-natured, Steady, Devoted, Obedient, Self-assured, Courageous, Calm, Fearless, Confident\r\nHeight	Male: 24â€“27 inches (61â€“68 cm)\r\nFemale: 22â€“25 inches (56â€“63 cm)\r\nWeight	Male: 43â€“59 kg\r\nFemale: 38â€“52 kg\r\nColors	Tan, Black, Mahogany', 'The Rottweiler physically strong, moves rapidly, momentum is powerful, is one of the most has the courage and strength of the dog in the world. The dogs have been used for guarding the cows are wise and strong, easy to breed. Now in the hand, the critically acclaimed, but also become extremely valuable family dogs. The Rottweiler is good dog, to attack the intruder. In order to let the dog did obey orders, breeders should strict training, dogs born with the talent, in the middle ages, rich businessmen in order to avoid the money stolen, the purse hanging in the Rottweiler neck. The dog personality stable, highly emotional, also can be a family companion.', '2015-04-07', 10, 24000, 'accept', 'QAMLT0F', 'Rottweiler-3.jpg'),
(12, 1, 13, 4, 'Name	Pug\r\nOther names	Chinese pug, Dutch bulldog, Dutch mastiff, Mini mastiff, Mops, Carlin\r\nOrigin	China\r\nSize Type	Small & Little & Tiny Dog Breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nLife span	12 -15 years\r\nTemperament	Playful, Stubborn, Attentive, Sociable, Clever, Charming, Docile, Quiet\r\nHeight	25 - 28 cm\r\nWeight	6 - 8 kg\r\nColors	Fawn, Black, Apricot, Silver Fawn', 'Pug is small dogs, pet dogs, a family companion, intelligent, stable personality, gentle, lively and full of fun, most likes playing with children, very suitable for feeding in the apartment.', '2015-04-07', 10, 30000, 'accept', '91PRJUA', 'Pug-3.jpg'),
(13, 1, 14, 4, 'Name	Rajapalyam dog\r\nOther names	Rajapalayam Hound, Indian sight-hound.\r\nOrigin	Indian\r\nSize Type	Large dog breeds\r\nBreed Group	Hound dog breeds\r\nLife span	 \r\nTemperament	Affectionate, Devoted\r\nHeight	65â€“75 cm (25â€“30 inches)\r\nWeight	 \r\nColors	Black, Brown, White', 'The Rajapalayam is an Indian Sighthound. It was the companion of the royalty and aristocracy in Southern India, particularly in the town Rajapalayam from where it gets its name.\r\nBody type\r\nIt is a large dog, usually measuring about 65â€“75 cm (25â€“30 inches) at the withers. It is a hound, and therefore should be kept in optimum working condition. It tends to be heavier boned than most sighthounds, but shares the depth of chest and basic body structure.', '2015-04-07', 5, 60000, 'accept', 'B5XDS7W', 'Rajapalyam-dog-3.jpg'),
(14, 1, 17, 4, 'Name	Manchester Terrier\r\nOther names	 \r\nOrigin	England\r\nSize Type	Small dog breeds\r\nBreed Group	Terrier dog breeds (AKC)\r\nLife span	14 - 16 years\r\nTemperament	Gay, Devoted, Active, Alert, Keen, Discerning\r\nHeight	Female: 39 - 42cm\r\nMale: 37 - 40cm\r\nWeight	7.5 - 8kg (12 to 22 pounds)\r\nColors	Black, Tan, Blue & Tan, Black & Tan, Blue', 'The Manchester Terrier inherited extinct black and Tan Terrier lineage, eighteenth Century, in Manchester by a man named John Hugh M breeders to develop the Manchester Terrier, Whippet and produced using hybrid varieties in Manchester, and later into the West Highland Terrier blood, the formation of the strains. The Manchester Terrier is visual hunting dogs, the dogs are used for two purposes of rabbit mouse. The dog is full of courage, agile, after a long time of mating, retains the unique and lively, smart, quick essence, improved the original rough impatient character. It is a ratter, at the end of the nineteenth Century was very popular in the rat race, there was a dog named Bailey killed 100 mice in a little more than six minutes.', '2015-04-07', 7, 21000, 'accept', 'J4ZAGI3', 'Manchester-Terrier-3.jpg'),
(15, 1, 18, 4, 'Name	Tibetan Spaniel\r\nOther names	Simkhyi, Tibbie\r\nOrigin	China\r\nSize Type	Small dog breeds\r\nBreed Group	Non-sporting dog breeds (AKC)\r\nCompanion Breeds (UKC)\r\nLife span	Average 12 to 15 years\r\nTemperament	Willful, Assertive, Intelligent, Aloof, Independent, Happy\r\nHeight	10 in (25 cm)\r\nWeight	9 to 15 lb (4.1 to 6.8 kg)\r\nColors	Cream, Red, Black & Tan, Sable, Gold, Black, White', 'Tibetan Spaniel is a compact, lively, and alert dog. The impression of appearance is well proportioned, slightly longer than the height at the withers. It is bright and breezy, very clever, avoid strangers. Although the name with the hound two words, but never participate in hunting activities, is just a name.\r\n\r\nTibetan Spaniel is often referred to as "sleeve dogs", originated in Himalaya mountains of Tibet, is an ancient Chinese breed one, is also a kind of fine mystery with dogs. After introduced from Tibet, the capital, reared in the Qing Dynasty palace, so the court said the dog. The dog character independence, self-confidence, is satisfactory companion dog.', '2015-04-07', 10, 42000, 'accept', 'PLX8MN9', 'Tibetan-Spaniel-3.jpg'),
(17, 2, 21, 0, 'Name	Maine Coon\r\nOther names	Coon Cat, Maine Cat, Maine Shag, Snowshoe Cat, American Longhair, The gentle giants\r\nOrigin	United States\r\nBody Type	Largest cat breeds\r\nCoat Length	Long hair\r\nTail Size	Thick Tail\r\nEyes	Large Eyes\r\nLife span	12-13 years\r\nTemperament	Gentle, Intelligent, Independent\r\nWeight & Height	Weigh: 15 - 25 lb (6.8 - 11 kg)\r\nHeight: 10 - 16 in (25 - 41 cm)\r\nColors	Black, White, Gray, Silver, Golden...', 'Maine Coon cat is Largest shaped longhair, strong, the soles of the feet is big and round. The middle face, ear height, ear, wide spaced eyes, M tiger forehead. Characteristics of purebred Maine Coon cat must have is: eye, lips and jaw pad must be black. Maine Coon cat hair color is very much, is estimated to have more than 60 coat pattern.', '2015-04-07', 9, 14000, 'accept', 'G7PQDA5', 'Maine-Coon-3.jpg'),
(18, 2, 22, 0, 'Name	Persian\r\nOther names	Longhair, Persian Longhair\r\nOrigin	Iran (Persia)\r\nBody Type	Medium-sized cat breeds\r\nCoat Length	Long hair\r\nTail Size	Medium Tail\r\nEyes	Large Eyes\r\nLife span	14-15 years\r\nTemperament	Gentle, Sensitive, Quiet, Ability\r\nWeight	3.5-7kg\r\nColors	White, Red, Black, Blue, Silver, Brown, Golden...', 'Persian cat is a cat in the noble, refined and cultured in temperament, smart, savvy, less quiet, gentle love cry a, coquetry, behave graceful bearing, naturally be spoiled state, give a person a kind of noble feeling. Has enjoyed the world people love cats love, is a long haired cats. Persian cat able-bodied, strong, simple lines of the body fluid; round, flat nose, Tuicu short, small ears, big eyes, a short tail.', '2015-04-07', 7, 16000, 'accept', '4RX8DUL', 'Persian-Cat-4.jpg'),
(19, 2, 19, 0, 'Name	Abyssinian\r\nOther names	 \r\nOrigin	Egypt\r\nBody Type	Medium size cat breeds\r\nCoat Length	Short Hair\r\nTail Size	Thick at base, fairly long and tapering.\r\nEyes	Large Eyes\r\nLife span	14-15 years\r\nTemperament	Gentle, Intelligent, Independent\r\nWeight	4-7.5kg\r\nColors	Blue, Chocolate, Cinnamon, Fawn, Ruddy', 'The legend of modern Abyssinian cat is ancient Egypt to be worshipped as "sacred" ancient Egyptian cat descended in the ancient Egyptian god of cat mummies, a blood red cat and it is very similar, therefore, many people think it is the direct descendant of the ancient Egyptian god of cat. Due to the overall shape, its hair color, erect ears are the same as the Bobcats to Africa, some people think that it originated from Africa lynx.', '2015-04-07', 7, 18000, 'accept', '09V17OM', 'Abyssinian-3.jpg'),
(20, 2, 24, 0, 'Name	Siamese\r\nOther names	Siam, Thai Cat\r\nOrigin	Thailand\r\nBody Type	Medium size cat breeds\r\nCoat Length	Short Hair\r\nTail Size	Thin Tail\r\nEyes	Medium Eyes\r\nLife span	12-20 years\r\nTemperament	Lively, Active, Amart, Clever, Agile, Elegant...\r\nWeight	2.5 - 5.5kg\r\nColors	Seal, Blue, Chocolate, Lilac...', 'Siamese cat (known as Siam, Thai Cat), Is the world famous Shorthair, represents the variety and shorthair. Racial history of Siam cat native to Thailand (named Siam), in 200 years ago, raising the precious cat only in Thailand soil palace and temples remain within doors, is noble.', '2015-04-07', 7, 22000, 'accept', 'EXTD13H', 'Siamese-3.jpg'),
(21, 2, 25, 0, 'Name	Birman\r\nOther names	Sacred Birman, Sacred Cat Of Burma\r\nOrigin	France\r\nBody Type	Medium Size cat breeds\r\nCoat Length	Long Hair\r\nTail Size	Medium in length\r\nEyes	Round Eyes\r\nLife span	14-15 years\r\nTemperament	Gentle, Kind, Gentle...\r\nWeight	4.5-5kg\r\nColors	Blue spot, stain stain seal, chocolate and lilac spots in four colors.', 'Name	Birman\r\nOther names	Sacred Birman, Sacred Cat Of Burma\r\nOrigin	France\r\nBody Type	Medium Size cat breeds\r\nCoat Length	Long Hair\r\nTail Size	Medium in length\r\nEyes	Round Eyes\r\nLife span	14-15 years\r\nTemperament	Gentle, Kind, Gentle...\r\nWeight	4.5-5kg\r\nColors	Blue spot, stain stain seal, chocolate and lilac spots in four colors.', '2015-04-07', 5, 16000, 'accept', 'Y0DM4BS', 'Birman-3.jpg'),
(22, 2, 26, 0, 'Name	American Shorthair\r\nOther names	Domestic Shorthair\r\nOrigin	United States\r\nBody Type	Medium and Large cat breeds\r\nCoat Length	Short Hair\r\nTail Size	Long Tail\r\nEyes	Large Eyes\r\nLife span	15-16 years\r\nTemperament	Active, Curious, Easy Going, Playful...\r\nWeight	4-6kg\r\nColors	Black, Blue, Brown, Silver, Tabby, Tabby and White', 'American Shorthair is a cat Native American ancestors, the early European immigrants brought the cat species in North America, similar with the British Shorthair and European shorthair. According to the record, the May flower contains several cat to help in rats. The breed of cat is in the streets and lanes to collect cats, and selection and imported varieties such as cultivating the British Shorthair cat, Burma and Persian cat hybrids formed. American Shorthair is heavyset, skeletal stout, muscular, naturally smart, gentle is known, is a large species shorthair class. Thickly furred coat color is dense, up more than 30 kinds of varieties, the valuable silver stripe.', '2015-04-07', 6, 27000, 'accept', '3HA7ZU2', 'American-Shorthair-3.jpg'),
(23, 2, 27, 0, 'Name	California Spangled\r\nOther names	Spangle\r\nOrigin	USA.California\r\nBody Type	Largest cat breeds\r\nCoat Length	Short Hair\r\nTail size	Long tail\r\nEyes	Small eyes\r\nLife span	10 -12 years\r\nTemperament	Curious,Intelligent,Loyal,Social\r\nWeight	 \r\nColors	Bronze, gold, blue, brown, charcoal, red, black, silver, or white', 'Origin of California and the hybrid cat. All is full of leopard speckle, with gold, silver and blue, brown and so on several kinds of coat, looks very beautiful. California bright cat character lively, intelligent and healthy, naturally gregarious, and can get on well with other cats or dogs, loyal to the master. The varieties of the current domestic rare.', '2015-04-07', 3, 20000, 'accept', 'J9ATPGX', 'California-Spangled-Cat-3.jpg'),
(24, 2, 28, 0, 'Name	Burmilla\r\nOther names	None\r\nOrigin	United Kingdom\r\nBody Type	Medium-sized cat breeds\r\nCoat Length	Short Hair\r\nTail size	Long tail\r\nEyes	Large eyes (Green)\r\nLife span	13 -16 years\r\nTemperament	Intelligent, Playful, Relaxed, Social, Sweet\r\nWeight	3â€“6 kg\r\nColors	Black, Blue, Brown, Chocolate, Cream, Lilac,Red, Tortoise Shell', 'Burmillas are medium-sized breeds cat, Origin: United Kingdom, weigh between 3â€“6 kg, Life span: 13 -16 years, Temperament:  In temperament they are sociable, playful, and affectionate, and get along well with children and other animals.', '2015-04-07', 6, 6000, 'accept', 'QMIDC58', 'Burmilla-3.jpg'),
(25, 2, 29, 0, 'Name	Ragdoll\r\nOther names	Rag doll\r\nOrigin	United States\r\nBody Type	Largest cat breeds\r\nCoat Length	Long Hair\r\nTail Size	Medium Tail\r\nEyes	Large Eyes\r\nLife span	18-20 years\r\nTemperament	Gentle, Quiet, Friendly...\r\nWeight	4.5-9Kg\r\nColors	Blue, Chocolate, Lilac, Red, Cream...', 'Ragdoll, also known as "Brasd cat", is a large cat in size and weight of a cat. V-shaped head, large round eyes, hair rich, thick limbs, tail length, body soft, multi-focus color, three-color or two-color cats.\r\n\r\nRagdoll docile and quiet, the people are very friendly, patient and strong, often mistaken for lack of pain. Ragdoll Because children can tolerate get caught, the most suitable for families with children feeding.', '2015-04-07', 7, 11000, 'accept', '4NJQ3GV', 'Ragdoll-3.jpg'),
(26, 1, 33, 0, 'Name	Japanese Spitz\r\nOther names	 \r\nOrigin	Japan\r\nSize Type	Small dog breeds\r\nBreed Group	Non-Sporting dog breeds\r\nLife span	 \r\nTemperament	Proud, Companionable, Playful, Affectionate, Obedient, Intelligent\r\nHeight	Male: 30 ~ 40 cm\r\nFemale: 25 ~ 35 cm\r\nWeight	6.5 ~ 10 kg\r\nColors	White', 'Japanese Spitz is an elegant, cheerful and dignified that has erect ears, high set tail is carried curled over the back, and a sparkling white coat that is outside the body. In proportion, the body is slightly longer than tall in a ratio of 11:10. The chest is broad and deep and ribs are well sprung. The cross is high and back straight and short. The back is broad and the belly is well covered.', '2015-04-27', 1, 12000, 'accept', 'URPOD32', 'Japanese-Spitz-3.jpg'),
(27, 1, 37, 0, 'Name	Rhodesian Ridgeback\r\nOther names	African Lion Boy, African Lion Girl\r\nOrigin	Rhodesia & Southern Rhodesia (Now Zimbabwe)\r\nSize Type	Large dog breeds\r\nBreed Group	Hound Dog Breeds (AKC)\r\nSighthounds & Pariahs (UKC)\r\nLife span	10 - 12 years\r\nTemperament	Dignified, Sensitive, Intelligent, Loyal, Mischievous, Strong Willed\r\nHeight	Female: 61â€“66 cm\r\nMale: 63â€“69 cm\r\nWeight	Female: 29â€“34 kg\r\nMale: 36â€“41 kg\r\nColors	Light Wheaten, Red Wheaten, Wheaten', 'Rhodesian Ridgeback body symmetry, color is light brown or red, limbs strong and powerful, muscular tail down, action. A stable personality wise, people close to the friendly, bark loud, personality stubborn, body smooth clean, is now very popular family dogs. Shape characteristics of the dog, the most prominent is the hair on the back and other parts of the body hair growth direction along the spine, with short hair, and reverse the growth of. Rhodesian Ridgeback brave struggle of good, strong tolerance, 24 hours of anhydrous could endure, in the interior of Africa to extreme temperatures in hunting can withstand, is a very good hunting dogs. In addition because it can hunt lion, also called lion dog.', '2015-04-27', 2, 70000, 'accept', 'LR2CG8M', 'Rhodesian-Ridgeback-3.jpg'),
(28, 1, 38, 0, 'Name	Dalmatian\r\nOther names	Dal, Dally, Carriage Dog, Spotted Coach Dog, Firehouse Dog, Plum Pudding Dog\r\nOrigin	Croatia\r\nSize Type	Large dog breeds\r\nBreed Group	Non-sporting dog breeds\r\nLife span	10 - 13 years\r\nTemperament	Active, Playful, Intelligent, Outgoing, Friendly, Energetic, Sensitive\r\nHeight	Female: 21â€“23 inches (54â€“59 cm)\r\nMale: 22â€“24 inches (56â€“61 cm)\r\nWeight	Female: 24â€“29 kg\r\nMale: 27â€“32 kg\r\nColors	Black & White, Liver & White', 'Dalmatian ( Dalmatian, also called the dog ), the origin of Croatia. Calm and alert, contour symmetry, strong, muscular, and lively, not shy expression, be clever and sensible, obedient easy training, perceptive, vigilance is strong, easy to get along with children. The Dalmatian dog has great powers of endurance, and run very fast. The hindquarters are powerful, have smooth and clear muscle. Dalmatian with running and biting ability outstanding, so it is often used to show dog.', '2015-04-27', 5, 44000, 'accept', 'UFN1047', 'Dalmatian-3.jpg'),
(29, 1, 39, 0, 'Name	Pekingese\r\nOther names	pekingese-lion dog, Lion Dog, Chinese Spaniel, Pelchie Dog, Peking Palasthund, Peke\r\nOrigin	China\r\nSize Type	Small dog breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nCompanion Breeds (UKC)\r\nLife span	12 - 15 years\r\nTemperament	Stubborn, Opinionated, Aggressive, Good-natured, Intelligent, Affectionate\r\nHeight	6â€“9 inches (15â€“23 cm)\r\nWeight	7â€“14 lb (3.2 to 6.4 kg)\r\nColors	Black, Cream, Fawn Brindle, Fawn, Grey, Black & Tan', 'Beijing dogs are also called the palace lion dog, Pekingese dogs, is the ancient Chinese, has four thousand years of history. Beijing is a well - balanced, compact dog, before the body weight and lighter hindquarters. It has the individuality, expressive, its image resembles a lion. It represents courage, daring, self-esteem is more than beautiful, elegant and refined.', '2015-04-27', 3, 33000, 'accept', 'Y7UPBXS', 'Pekingese-3.jpg'),
(30, 1, 40, 0, 'Name	Italian Greyhound\r\nOther names	Italian Greyhound: French: Petit Levrier Italiane, Italian: ,Piccolo Levriero Italiano; German: Italienisches Windspiel; Spanish: Galgo italiano\r\nOrigin	Italy\r\nSize Type	Small dog breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nLife span	12 - 15 years\r\nTemperament	Affectionate, Agile, Athletic, Companionable, Intelligent, Mischievous\r\nHeight	13 - 15 inches\r\nWeight	7 - 15 pounds\r\nColors	Red Fawn, Black, Sable, Blue Fawn, Blue, Tan, Fawn, Chocolate, Red, Yellow, Slate Grey, Grey', 'As its name suggests, the Italian Greyhound is very similar to the Greyhound much larger, although they are much smaller and more slender in all proportions. The Italian Greyhound is a breed of supreme elegance and grace.\r\nThe body length is short half together with the extra length being in the rib cage. The chest is narrow, deep and let down your elbows as close as possible. The cross is high. The top line shows a slight increase, with the highest point at the start of the back, falling on the rump sloping harmoniously, creating a definite aesthetic up on the flanks.', '2015-04-27', 3, 38000, 'accept', 'XA9I5KH', 'Italian-Greyhound-3.jpg'),
(31, 1, 41, 0, 'Name	Maltese\r\nOther names	Maltese Dog\r\nOrigin	Malta\r\nSize Type	Small dog breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nLife span	12 -15 years\r\nTemperament	Active, Playful, Affectionate, Gentle, Intelligent, Lively, Docile\r\nHeight	Male: 8-10 in\r\nFemale: 8-9 in\r\nWeight	Male: 3-8 lb\r\nFemale: 2-7 lb\r\nColors	White', 'The Maltese is a toy dog covered from head to foot with a mantle of long, silky, white hair. He is gentle-mannered and affectionate, eager and sprightly in action, and, despite his size, possessed of the vigor needed for the satisfactory companion.', '2015-04-27', 3, 55000, 'accept', '4G63XBP', 'Japanese-Spitz-3.jpg'),
(32, 1, 42, 0, 'Name	South Russian Ovcharka\r\nOther names	IoujnorousskaÃ¯a Ovtcharka, South Russian Sheepdog, Ukrainian Ovcharka, Yuzhak, South Ukrainian Ovcharka, South Russian Shepherd Dog\r\nOrigin	Ukraine, Russia\r\nSize Type	Large dog breeds\r\nBreed Group	Guardian Dogs (UKC)\r\nLife span	12 -15 yrs\r\nTemperament	Active, Lively, Balanced, Nervous\r\nHeight	Female: 62â€“66 cm\r\nMale: 65â€“66 cm\r\nWeight	Female: 48â€“50 kg\r\nMale: 48â€“50 kg\r\nColors	Grey, White, Gray & White, White & Yellow, Deadgrass', 'The South Russian Shepherd Dog is a dog of above average size and sturdily built, with a thick, dense, double coat. The race is slim, but with a massive bone structure and musculature well developed. Secondary sex characteristics are strongly marked, with males being stronger, more massive and more courageous than females.', '2015-04-27', 3, 60000, 'accept', 'YXBOR9T', 'South-Russian-Ovcharka-3.jpg'),
(33, 1, 43, 0, 'Name	Chihuahua\r\nOther names	Chihuahua dog\r\nOrigin	Mexico\r\nSize Type	Small & Tiny  dog breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nLife span	12 -18 years\r\nTemperament	Alert, Devoted, Quick, Courageous, Lively\r\nHeight	Male: 6â€“10 inches (15â€“23 centimeters)\r\nFemale: 6â€“10 inches (15â€“23 centimeters)\r\nWeight	Male: Under 6 pounds (Under 3 kilograms)\r\nFemale: Under 6 pounds (Under 3 kilograms)\r\nColors	White, black, tan and many other colors', 'Chihuahuas are not only cute small dog toy, but also have a large dogs hunting and guarding instincts, with similar Terrier temperament. The dogs were divided into long and short for. The dogs petite size, other dogs is not timid, to master very exclusive heart. Short and long for difference is shiny, skin, soft undercoat. Long wool breed Chihuahua except the back wool rich, like Shorthair as shivering tendency.\r\n\r\nA graceful, alert, swift-moving compact little dog with saucy expression, and with terrier-like qualities of temperament.', '2015-04-27', 3, 60000, 'accept', 'WCRF6ZV', 'Chihuahua-3.jpg'),
(34, 1, 44, 0, 'Name	Lhasa Apso\r\nOther names	Tibet, Lhasa, Tibet Lhasa lion dog, Tibet dog Yabusu\r\nOrigin	Qinghai-Tibet Plateau, Tibetan Plateau\r\nSize Type	Small dog breeds\r\nBreed Group	Non-sporting dog breeds (AKC)\r\nCompanion Breeds (UKC)\r\nLife span	12 - 14 years\r\nTemperament	Energetic, Playful, Fearless, Friendly, Assertive, Intelligent, Lively, Spirited, Steady, Devoted, Obedient, Alert\r\nHeight	Female: 25â€“28 cm\r\nMale: 25â€“28 cm\r\nWeight	Female: 5â€“7 kg\r\nMale: 6â€“8 kg\r\nColors	Black, Golden, Sandy, Honey, Dark Grizzle, Brown', 'Lhasa dog body looks like a lion, hair long and rich, especially the head, ears, tail hair is the most abundant, can be dragged to the ground. Good beard and Long Yan Bin, Onoue, chrysanthemum shaped tail. It is the ideal family dog. Lhasa is also known as the "holy dogs of exorcism".', '2015-04-27', 5, 32000, 'accept', 'E0M41OH', 'Lhasa-Apso-3.jpg'),
(35, 1, 45, 0, 'Name	Pembroke Welsh Corgi\r\nOther names	Pembroke, PWC, Pem, corgi\r\nOrigin	Wales\r\nSize Type	Small & Little & Tiny Dog Breeds\r\nBreed Group	Herding dog breeds (AKC)\r\nLife span	12 -14 years\r\nTemperament	Playful, Outgoing, Friendly, Protective, Tenacious, Bold\r\nHeight	Male: 10â€“12 inches (25â€“30 cm)\r\nFemale: 10â€“12 inches (25â€“30 cm)\r\nWeight	Male: 10â€“12 kg\r\nFemale: 10â€“11 kg\r\nColors	Fawn, Red, Blue, Black & White, Black & Tan, Sable', 'The Pembroke is one of two Welsh Corgi breeds, the other being the Cardigan. Several theories exist regarding the origin of these very old breeds, one being that they were brought to Wales by the Celts. Another theory is that they are descended from the Swedish Vallhunds, which were crossed with the local Welsh herding dogs. The Pembroke is a herding dog, originally used to drive cattle to pasture.', '2015-04-27', 6, 32000, 'accept', 'YBR7LVE', 'Pembroke-Welsh-Corgi-3.jpg'),
(36, 1, 46, 0, 'Name	Glen of Imaal Terrier\r\nOther names	Irish Glen of Imaal Terrier, Wicklow Terrier, Glen\r\nOrigin	Ireland\r\nSize Type	Small dog breeds\r\nBreed Group	Terrier dog breeds (AKC)(UKC)\r\nLife span	14 - 15 years\r\nTemperament	Agile, Spirited, Gentle, Active, Loyal, Courageous\r\nHeight	12 - 14 inches\r\nWeight	32 - 40 pounds\r\nColors	Wheaten, Blue Brindle', 'Glen of Imaal Terrier, named for the region in the Wicklow Mountains of Ireland, which was developed long ago, is a medium-sized working terrier. Longer than tall and sporting a double coat of medium length, the Glen has great strength and always should be the impression of maximum substance for size of dog. Unrefined to this day, the breed still has "old" account once common to many early terrier types, their distinctive head with rose or half prick ears, his curved forequarters with turned feet, your sole and top line contour are the characteristics of the breed and essential to breed type.', '2015-04-27', 6, 45000, 'accept', 'ZB8UXNS', 'Glen-of-Imaal-Terrier-3.jpg'),
(37, 1, 48, 0, 'Name	Bichon Frise\r\nOther names	Bichon Ã  poil frisÃ©, Bichon Tenerife, Purebred Bichon\r\nOrigin	Spain , Belgium,  France\r\nSize Type	Small Dog Breeds\r\nBreed Group	Non-Sporting dog breeds (AKC)\r\nLife span	12 - 15  years\r\nTemperament	Playful, Affectionate, Gentle, Sensitive, Cheerful, Feisty\r\nHeight	Male: 9â€“12 inches (23â€“30 cm)\r\nFemale: 9â€“11 inches (23â€“28 cm)\r\nWeight	Male: 3â€“5 kg\r\nFemale: 3â€“5 kg\r\nColors	White, White & Apricot, White & Buff, White & Cream', 'The Bichon Frise is small, compact and sturdy in appearance, with medium bone, never appearing coarse or fine. Its dense, white coat gives the breed the appearance of a white powder puff. It moves jauntily, with high head carriage and its plumed tail carried over its back.', '2015-04-27', 5, 34000, 'accept', 'ID1MVJ2', 'Bichon-Frise-3.jpg'),
(38, 1, 49, 0, 'Name	Chinese Crested\r\nOther names	Crested, Puff\r\nOrigin	China, Africa, Mexico\r\nSize Type	Small dog breeds\r\nBreed Group	Toy dog breeds (AKC)\r\nLife span	12 - 14  years\r\nTemperament	Happy, Playful, Affectionate, Alert, Lively, Sweet-Tempered\r\nHeight	Female: 9â€“12 inches (23â€“30 cm)\r\nMale: 11â€“13 inches (28â€“33 cm)\r\nWeight	Female: 2.3â€“5.4 kg\r\nMale: 2.3â€“5.4 kg\r\nColors	Black, Cream, Blue, Chocolate, Apricot, Tri-color', 'Chinese Crested Dog is one of only a handful of hairless dog breeds in the world. Native to China small to enjoy the dog, because the dog head crest, which is the Qing Dynasty official hat so named Chinese Crested dog has two variants. In 1975 the United States began to introduce. It belongs to the toy dog, is not big, the general height not exceeding 33 cm. Its skin color design, color diversity, common are black with blue plaque, a pink bottom with brown plaques. Chinese Crested dog loves clean, lint-free, gentle, loving and affectionate, is a very suitable family cultivation to enjoy the dog.', '2015-04-27', 3, 50000, 'accept', '0912SPO', 'Chinese-Crested-3.jpg'),
(39, 1, 50, 0, 'Name	German Pinscher\r\nOther names	Deutscher Pinscher\r\nOrigin	Germany\r\nSize Type	Medium dog breeds\r\nBreed Group	Working dog breeds (AKC)\r\nTerrier dog breeds (UKC)\r\nLife span	12 - 14 years\r\nTemperament	Even Tempered, Spirited, Lively, Loving, Familial, Intelligent\r\nHeight	17-20 inches\r\nWeight	25-35 pounds\r\nColors	Brown, Black, Fawn, Red, Blue', 'German Pinscher is well balanced, well muscled, powerful, full built, medium size, with elegant, flowing lines.\r\nThe body is compact, short-coupled. Body length is approximately equal to the height of the dog, measured at the cross.The chest is moderately wide with flat ribs. The chest extends below the elbow. The ledge extends beyond the tip of the shoulder. The back is short and there is a slight increase in the loins.', '2015-04-27', 3, 88000, 'accept', 'N9MJ5VK', 'German-Pinscher-3.jpg'),
(40, 2, 53, 0, 'SIZE\r\nMedium to large, with males weighing 9 to 14 pounds and females weighing 7 to 11 pounds\r\nCOAT\r\nLong, thick, glossy\r\nSHEDS\r\nYes\r\nCOLOR\r\nWhite, blue, black, red, cream, chocolate, lilac\r\nVOCALIZATION\r\nSoft, pleasant voice\r\nTEMPERAMENT\r\nAffectionate, loyal, sedate', 'A gorgeous longhair breed with a pansylike face, the Persian looks like a fluff ball but under the coat is a muscular, sturdy body. With her sweet personality, the Persian is a charming pet for all ages. The breed features solid, bicolor, calico and tabby varieties, which include a multitude of colors and patterns. The Persian Solid may be colored white, blue, black, red, cream, chocolate, and lilac. All have brilliant copper eyes, except the pristine white solid color, which may be copper, deep blue or a combination of blue and copper. The Persian Bicolor features a combination of colors as well as patterns of tabby. All have brilliant copper eyes, except the silver tabby with white, which may have green or hazel eyes. The Persian Calico has a white coat splashed with vivid patches of red and black. The dilute calico is patched with blue and cream, and chocolate and lilac calicos have patches of chocolate and red or lilac and cream, respectively. The Persian Tabby, known for being extroverted and fun, comes in three patterns, classic, mackerel and patched. This breed requires daily brushing and occasional baths and should strictly be an indoor pet.', '2015-04-27', 5, 150000, 'accept', 'YGCWAKB', 'PersianSolid_body.jpeg'),
(41, 3, 54, 0, 'Temperament: Community\r\nReef Safe: No\r\nFamily: Monodactylidae\r\nNative To: Sri Lanka\r\nDiet: Omnivore\r\nAdult Size: Up to 10"\r\nTemperature: 72-82Â°F\r\nWater Parameters: SG 1.010-1.015 pH 7.5-8.4\r\nCare Level: Moderate\r\nTank Size: 55+ Gallons\r\nScientific Name: Mono argentatus\r\nEnvironment: Brackish\r\nGrows large up to 10 inches\r\nShows best adult coloration in a marine environment\r\nSchooling fish best kept in groups of 3 or more', 'The Silver Mono, also known as Silver Moonfish, Silver Batfish and Fingerfish, are found in freshwater, estuaries swimming among mangrove trees and full marine environments. Young Monos can be kept in fresh or brackish water but as they mature they prefer to be kept in full marine environment where they spend most of their adult life and show their best coloration. The Silver Mono can grow rather large usually obtaining a size of 10" in the home aquarium and require a large aquarium as they mature. The can be shy and timid. Provide plenty of hiding places and cover. They like to school and 3 or more are recommended. Silver Mono are hardy eaters and will eat almost anything. They are peaceful but can eat smaller fish so best kept with fish larger than their mouths.', '2015-04-27', 10, 900, 'accept', 'LEUFRYZ', '1326686C.jpg'),
(42, 3, 55, 0, 'Temperament: Semi-aggressive\r\nReef Safe: No\r\nFamily: Scatophagidae\r\nNative To: Sri Lanka\r\nDiet: Omnivore\r\nAdult Size: Up to 12"\r\nTemperature: 72-82Â°F\r\nWater Parameters: SG 1.010-1.015 pH 7.5-8.4\r\nCare Level: Moderate\r\nTank Size: 55+ gallons\r\nScientific Name: Scatophagus argus\r\nEnvironment: Brackish', 'The Spotted Scat, also known as the Red or Ruby Scat, are found in freshwater, estuaries swimming among mangrove trees and full marine environments. Young Scats can be kept in fresh or brackish water but as they mature they prefer to be kept in full marine environment where they spend most of their adult life and show their best coloration. The Spotted Scat can grow rather large usually obtaining a size of 12" in the home aquarium and require a large aquarium as they mature. Provide plenty of hiding places and cover. Spotted Scats are hardy eaters and will eat almost anything. They are also known to consume the feces of other fish.', '2015-04-27', 10, 820, 'accept', 'UVSZAOG', '1326678C.jpg'),
(43, 3, 57, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Also known as Siamese Fighting Fish, Combattant (Canada), Trey kroem phloek (Cambodia), or CÃ¡ lia thia (Vietnam).\r\n\r\nThe Male Veiltail Betta is well known for its jewel-bright colors and spectacular fins. Bettas are anabantids (Derived from the Greek Verb anabaino, meaning "to go up") which physiologically means they have two methods of breathing. Bettas breathe from their labyrinth organ which enables the fish to breathe from the surface. Bettas also breathe through their gills like other fish. Genetically speaking, the veil tail trait is dominant over the short fins.\r\n\r\nBettas will "flare" their fins when disturbed or threatened. The Male Veiltail Betta will attack another Betta and have been known to attack similar-looking fish. It is recommended that only one Male Veiltail Betta is housed in an aquarium with plants and very little current.', '2015-04-27', 10, 60, 'accept', 'U2DHVC0', '1031759C.jpg'),
(44, 3, 58, 0, 'Temperament: Community\r\nFamily: Poeciliidae\r\nNative To: Central and South America\r\nDiet: Omnivore\r\nAdult Size: Up to 2.5"\r\nTemperature: 72Â° - 82Â°F\r\nCare Level: Easy\r\nTank Size: 10+ gallons\r\nScientific Name: Poecilia reticulata\r\nEnvironment: Freshwater', 'Also known as Guppie or Miljoenvis (South Africa), Wilder Riesenguppy or Millionenfisch (Germany), Poisson million (French Polynesia), Gupik pawie (Poland), Sarapintado (Brazil), Bunting or Sibolon perut (Indonesia), or Millions Fish.\r\n\r\nGuppies are a classic aquarium fish. Females are larger in size than the males, have a rounder anal fin and are not as brightly colored as the males. They have been bred for a variety of colors, patterns and fin shapes and are generally named for the color of their tail, tail shape, and body coloration. A schooling fish, it does best when housed in groups of five or more of the same species. Does best in a planted community tank with no fin nippers. Guppies come in a wide variety of patterns or strains as well as a multitude of tail shapes.', '2015-04-27', 10, 750, 'accept', 'PJ84KYD', '1032089C.jpg'),
(45, 3, 59, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nTemperature: 74Â° - 82Â°F\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Also known as Siamese Fighting Fish, Combattant (Canada), Trey kroem phloek (Cambodia), or CÃ¡ lia thia (Vietnam).\r\n\r\nThis specific fish comes in shades of blue. There may be hints of reds or greens.\r\n\r\nThe Blue Male Veiltail Betta is well known for its jewel-bright colors and spectacular fins. The blues in Bettas can range from Steel Blue to Royal Blue. Bettas are anabantids (Derived from the Greek Verb anabaino, meaning "to go up") which physiologically means they have two methods of breathing. Bettas breathe from their labyrinth organ which enables the fish to breathe from the surface. Bettas also breathe through their gills like other fish. Genetically speaking, the veil tail trait is dominant over the short fins.\r\n\r\nBettas will "flare" their fins when disturbed or threatened. The Blue Male Veiltail Betta will attack another Betta and have been known to attack similar-looking fish. It is recommended that only one Male Betta is housed in an aquarium with plants and very little current.', '2015-04-27', 10, 150, 'accept', 'DAM5Q0H', '1397591C.jpg'),
(46, 3, 61, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Also known as Siamese Fighting Fish, Combattant (Canada), Trey kroem phloek (Cambodia), or CÃ¡ lia thia (Vietnam).\r\n\r\nThe Male Betta is well known for its jewel-bright colors and spectacular fins. Bettas are anabantids (Derived from the Greek Verb anabaino, meaning "to go up") which physiologically means they have two methods of breathing. Bettas breathe from their labyrinth organ which enables the fish to breathe from the surface. Bettas also breathe through their gills like other fish.\r\n\r\nAs the name suggests, the Male Halfmoon Betta has a large tail in the shape of a halfmoon. The angle is from 170Â° to a perfect 180Â° tail span. This tail variation is one of the most beautiful, yet fragile of the Bettas that has been bred within the past decade or so.\r\n\r\nBettas will "flare" their fins when disturbed or threatened. The male Betta will attack another Betta and have been known to attack similar-looking fish. It is recommended that only one male Betta is housed in an aquarium with plants and very little current.', '2015-04-27', 7, 700, 'accept', 'BE75JVU', '1031740C.jpg'),
(47, 3, 62, 0, 'Temperament: Community\r\nFamily: Cyprinidae\r\nNative To: Asia\r\nDiet: Omnivore\r\nAdult Size: Up to 8"\r\nTemperature: 64 - 75Â°F\r\nCare Level: Easy\r\nTank Size: Pond/ 30+ gallons\r\nScientific Name: Carassius auratus\r\nEnvironment: Freshwater', 'Due to the long and fluttery fins of a Red Fantail Goldfish, this fish does best with other slow swimmers. These fish come in a wide variety of colors and patterns ranging from Calico to Metallic Red to Silver. This specific one has an appearance that consists of Red with hints of Orange. Related to carp, Goldfish prefer cool temperatures compared to Tropical Fish. Live plants are not the best option to have in a tank with this fish as they will nip at leaves, damaging a plant until it rots away. Red Fantail Goldfish will also dig at the substrate creating divots and small valleys. These fish may also be candidates to keep in a pond as well, similar to Koi.', '2015-04-27', 10, 700, 'accept', 'XMZO8H7', '1433520C.jpg'),
(48, 3, 63, 0, 'Temperament: Semi-aggressive\r\nFamily: Cichlidae\r\nNative To: South America\r\nDiet: Omnivore\r\nAdult Size: Up to 12"\r\nTemperature: 75 - 82Â°F\r\nCare Level: Moderate\r\nTank Size: 30+ gallons\r\nScientific Name: Pterophyllum sp.\r\nEnvironment: Freshwater', 'Its scientific name is derived from the Greek words meaning "winged leaf" and "ladder". This is referring to its laterally compressed body, and tall dorsal fin. Angelfish are found in the wild around dense vegetation.\r\n\r\nA planted tank with plenty of swimming space is recommended. Regular partial water changes are essential for all Freshwater Angelfish. Poor water quality will lead to the fish refusing to eat leading to illness and possibly mortality. Angelfish are one of the many freshwater fish that come in a variety of colorations and patterns.', '2015-04-27', 10, 450, 'accept', 'G7I84BM', '1433172C.jpg'),
(49, 3, 64, 0, 'Temperament: Community\r\nFamily: Cyprinidae\r\nNative To: Asia\r\nDiet: Omnivore\r\nAdult Size: Up to 8"\r\nTemperature: 64Â° - 75Â°F\r\nCare Level: Easy\r\nTank Size: Pond/ 30+ gallons\r\nScientific Name: Carassius auratus\r\nEnvironment: Freshwater', 'Due to the long and fluttery fins of a Purple Fantail Goldfish, this fish does best with other slow swimmers. These fish has a purplish maroon coloration. Related to carp, Goldfish prefer cool temperatures compared to Tropical Fish. Live plants are not the best option to have in a tank with this fish as they will nip at leaves, damaging a plant until it rots away. Purple Fantail Goldfish will also dig at the substrate creating divots and small valleys. These fish may also be candidates to keep in a pond as well, similar to Koi.', '2015-04-27', 10, 950, 'accept', 'WHBLNJY', '1433423C.jpg'),
(50, 3, 65, 0, 'Temperament: Community\r\nFamily: Cyprinidae\r\nNative To: Asia\r\nDiet: Omnivore\r\nAdult Size: Up to 8"\r\nTemperature: 64 - 75Â°F\r\nCare Level: Easy\r\nTank Size: Pond/ 30+ gallons\r\nScientific Name: Carassius auratus\r\nEnvironment: Freshwater', 'Due to the long and fluttery fins of a Red and White Goldfish, this fish does best with other slow swimmers. These fish come in a wide variety of colors and patterns ranging from Calico to Metallic Red to Silver. This specific one has an appearance that consists of Red and White markings. Related to carp, Goldfish prefer cool temperatures compared to Tropical Fish. Live plants are not the best option to have in a tank with this fish as they will nip at leaves, damaging a plant until it rots away. Red and White Fantail Goldfish will also dig at the substrate creating divots and small valleys. These fish may also be candidates to keep in a pond as well, similar to Koi.', '2015-04-27', 10, 960, 'accept', 'QHM64G1', '1433474C.jpg'),
(51, 3, 66, 0, 'Temperament: Aggressive\r\nFamily: Cichlidae\r\nNative To: South America: Amazon\r\nDiet: Carnivore\r\nAdult Size: Up to 12"\r\nTemperature: 72Â° - 82Â°F\r\nCare Level: Easy\r\nTank Size: 55+ gallons\r\nScientific Name: Astronotus ocellatus\r\nEnvironment: Freshwater', 'Also known as Apaiari (Brazil), CaraussÃº (Argentina), or AcarahuazÃº (Peru).\r\n\r\nThe Tiger Oscar has an extroverted personality and somewhat interactive behavior. They can learn to recognize their mate, as well as their owner. The Tiger Oscar Cichlid is primarily chocolate in color with orange-red markings and a brightly colored eyespot located on the dorsal fin. Oscars tend to dig up plants, as well as rearrange rocks and gravel. Oscar Cichlids should be kept with fish of similar size as they can and will eat smaller fish', '2015-04-27', 10, 2100, 'accept', '598JTSU', '1031856C.jpg');
INSERT INTO `tbl_sale` (`saleid`, `catid`, `subcatid`, `userid`, `briefdesc`, `detaildesc`, `posted_date`, `itemcount`, `rate`, `status`, `orderno`, `image`) VALUES
(52, 3, 67, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Also known as Siamese Fighting Fish, Combattant (Canada), Trey kroem phloek (Cambodia), or CÃ¡ lia thia (Vietnam).\r\n\r\nThis specific fish comes in shades of blue. There may be hints of reds or greens.\r\n\r\nBettas are anabantids (Derived from the Greek Verb anabaino, meaning "to go up") which physiologically means they have two methods of breathing. Bettas breathe from their labyrinth organ which enables the fish to breathe from the surface. Bettas also breathe through their gills like other fish.\r\n\r\nBlue Male Crowntail Bettas have stunning tails with single or double ray patterns in a range of colors. The blues in Bettas can range from Steel Blue to Royal Blue. This finnage was first acknowledged as an official Betta Tail and Fin form in 1997 in Indonesia. Bettas will "flare" their fins when disturbed or threatened. The male Betta will attack another Betta (Male or Female) and have been known to attack similar-looking fish. It is recommended that only one male Betta is housed in an aquarium with plants and very little current.', '2015-04-27', 10, 460, 'accept', 'VEMKIN5', '1397664C.jpg'),
(53, 3, 68, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'A Betta fish makes a great companion, especially if you donâ€™t have the time or room to care for a pet with greater needs. If you want a truly special fish, choose the Elephant Ear Halfmoon Plakat Betta. This colorful and graceful live Betta fish comes with large pectoral fins that look like an elephantâ€™s ear.\r\n\r\nBetta fish are a great option if you want to keep a pet at work, in a small apartment or in a dorm room. They can comfortably live in just a liter of freshwater and are very easy to care for. These bright and beautiful fish are a joy to watch, especially as their graceful fins and tail fan out in calm water. Unlike other live fish for sale, live Betta fish breathe from a set of gills as well as a labyrinth organ, which allows them to breathe from the surface. Watch your Betta, and youâ€™ll notice the fish swim to the surface to gulp air.\r\n\r\nThe Elephant Ear Halfmoon Plakat Betta is a special live fish for sale. Its large pectoral fins look like an elephant ear, giving this Betta a look that is unique among live Betta fish. The second part of its name refers to the fishâ€™s tail, which has a rounded edge like a half moon. Plakat Bettas typically have shorter fins than most other Bettas and closer resemble the wild variety of Betta splendens. Watch what happens when your fished is surprised. Your Elephant Ear Halfmoon Plakat Betta will flare its fins and tail to look intimidating.\r\n\r\nIf you are considering a live fish for sale, a Betta really is a wonderful choice. Youâ€™ll get beauty and low maintenance in the same package. Just take care to meet the needs of your new pet. Bettas do not do best in the company of other fish and are more successfully kept when housed alone in an aquarium with plants and very little current. Please note that Betta supplies, like an aquarium, plants and fish food, are sold separately.', '2015-04-27', 10, 1600, 'accept', 'MKXCTZ4', '555551545819C.jpg'),
(54, 3, 69, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Betta fish can make fantastic pets. They are beautiful to look at as well as relatively easy to care for. If you want a unique Betta that will really turn some heads, choose the Elephant Ear Halfmoon Betta. This brightly colored fish gets its name from its special pectoral fins, which resemble an elephantâ€™s ear.\r\n\r\nLive Betta fish are a great choice for busy professionals, hectic college students and even children ready for their first pet. An Elephant Ear Halfmoon Betta can live comfortably in just a liter of water. A tank this size can easily fit on a desk at work, in a small cubicle or in a childâ€™s bedroom. Your live Betta fish doesnâ€™t even need a filter. Just clean the tank regularly, and your Betta will be content. A well cared for Betta can live for several years.\r\n\r\nIf you are looking at live fish for sale, there are even more reasons to choose a Betta. These fish are absolutely gorgeous. They come in a variety of colors, from shimmering blue to deep crimson. They have long fins and tails that flow beautifully in calm water. You are sure to enjoy watching your Betta. The Elephant Ear Halfmoon Betta, in particular, has large pectoral fins that resemble an elephantâ€™s ear. Its tail has a rounded edge, which makes it look like a half moon. When the fish flairs, its tail spreads all the way to a 180Â° angle.\r\n\r\nLive Betta fish are also unique in that they can breathe in two different ways. Like all fish, they rely on a set of gills to breathe underwater. But they also possess a labyrinth organ that allows them to breathe air. Itâ€™s a delight to watch your Betta swim to the surface of the tank and gulp the air. Males Bettas may even make nests at the surface out of little pearl-like bubbles, which indicates ideal water conditions.\r\n\r\nIf you are considering a live fish for sale like a Betta, please note that supplies like a tank, food and water conditioner are sold separately. Before getting a live fish for sale, make sure you understand the needs of your particular pet. Betta fish, for instance, feel stress in the presence of other fish. They are most comfortable and healthy when housed alone.', '2015-04-27', 10, 1400, 'accept', '3HW7VPD', '2137318C.jpg'),
(55, 3, 70, 0, 'Temperament: Community\r\nFamily: Belontiidae\r\nNative To: S.E. Asia - Cambodia, Thailand\r\nDiet: Carnivore\r\nAdult Size: Up to 3"\r\nWater Current: Low\r\nTemperature: 74Â° - 82Â°F\r\nWater Parameters: KH 0-25, pH 6.0-8.0\r\nCare Level: Easy\r\nTank Size: 1+ liter\r\nScientific Name: Betta splendens\r\nEnvironment: Freshwater', 'Also known as Siamese Fighting Fish, Combattant (Canada), Trey kroem phloek (Cambodia), or CÃ¡ lia thia (Vietnam).\r\n\r\nThis fish comes in shades of Red, with some pinks or blacks throughout the body or fins.\r\n\r\nBettas are anabantids (Derived from the Greek Verb anabaino, meaning "to go up") which physiologically means they have two methods of breathing. Bettas breathe from their labyrinth organ which enables the fish to breathe from the surface. Bettas also breathe through their gills like other fish.\r\n\r\nRed Male Crowntail Bettas have stunning tails with single or double ray patterns in a range of colors. This specific fish comes in a wide variety of reds, ranging from Crimson Red to Red Brown. This finnage was first acknowledged as an official Betta Tail and Fin form in 1997 in Indonesia. Bettas will "flare" their fins when disturbed or threatened. The male Betta will attack another Betta (Male or Female) and have been known to attack similar-looking fish. It is recommended that only one male Betta is housed in an aquarium with plants and very little current.', '2015-04-27', 10, 170, 'accept', 'BKN875F', '1397656C.jpg'),
(56, 3, 73, 0, 'Temperament: Community\r\nFamily: Cichlidae\r\nNative To: Amazon River Basin\r\nDiet: Carnivore\r\nAdult Size: Up to 12"\r\nTemperature: 80Â° - 84Â°F\r\nCare Level: Difficult\r\nTank Size: 30+ gallons\r\nScientific Name: Symphysodon sp.\r\nEnvironment: Freshwater', 'Also known as Diskusfisk (Sweden), Disco azul (Peru), GrÃ¼ner Diskus(Germany), or Brun Diskosfisk (Denmark).\r\nThe body of the Discus is round and laterally compressed, an unusual characteristic of the Cichlidae family which makes it suitable for gliding through tall aquarium grasses. Discus are vibrantly colored with vertical or horizontal stripes. The Pigeon Blood Discus is a vivid orange with black marbling; the fins are brown with a hint of turquoise. Needs plenty of hiding spots especially tall live plants. The Pigeon Blood Discus changes to different shades of orange and black depending on its mood and health.\r\n\r\nDiscus require special attention, needing low lighting, dark substrate, and soft water. Water conditioner or Reverse Osmosis filtration to soften the water is highly recommended', '2015-04-27', 10, 42000, 'accept', 'DG96M4X', '1031910C.jpg'),
(57, 3, 74, 0, 'Temperament: Community\r\nFamily: Balitoridae\r\nNative To: China\r\nDiet: Omnivore\r\nAdult Size: Up to 4"\r\nTemperature: 72Â° - 82Â°F\r\nWater Parameters: pH 6.0-8.0; KH 4-12\r\nCare Level: Easy\r\nTank Size: 10+ gallons\r\nScientific Name: Gastromyzon sp.\r\nEnvironment: Freshwater', 'Also known as the Hillstream Loach, Butterfly Pleco or Chinese Pleco. Borneo Suckers look similar to the plecostomus but they are not. They can attach themselves to hard surfaces using specially adapted mouth parts. Borneo Suckers are scavengers and will eat almost anything as well as algae. This species prefers fast moving water with a high oxygen content. Good community fish as they have a peaceful disposition. Provide plenty of rocks, plants and driftwood.', '2015-04-27', 10, 600, 'accept', 'JZKD2CY', '1433865C.jpg'),
(58, 3, 75, 0, 'Temperament: Community\r\nFamily: Cyprinidae\r\nNative To: Asia\r\nDiet: Omnivore\r\nAdult Size: Up to 10"\r\nTemperature: 64Â° - 75Â°F\r\nCare Level: Easy\r\nTank Size: Pond/ 30+ gallons\r\nScientific Name: Carassius auratus\r\nEnvironment: Freshwater', 'Also known as the Popeye or Black Dragon Eye Goldfish.\r\n\r\nThis goldfish has an egg shaped body, with its most distinctive feature, bulbous protruding eyes. However, due to the nature of its eyes, the Black Moor Goldfish has a difficult time seeing its food. Also, due to the long flowing finnage it is a slower than average swimmer. This makes it quite of a challenge for the Black Moor Goldfish to compete against faster swimming fish such as shubunkins.\r\n\r\nThis variety of goldfish is also very social with other fish, swimming near and around other fish without any form of hostility. Black Moor Goldfish have been known to dig up gravel and plants. Needs plenty of room to swim as it is a relatively wide fish. Sharp edges on dÃ©cor are discouraged due to their somewhat fragile eyes. Given proper care, goldfish have been known to live upwards of 20 years of age.', '2015-04-27', 10, 8400, 'accept', 'BM204J8', '1031988C.jpg'),
(59, 3, 77, 0, 'Temperament: Community\r\nReef Safe: With Caution\r\nFamily: Chaetodontidae\r\nNative To: Indo-Pacific\r\nDiet: Carnivore\r\nAdult Size: Up to 8"\r\nTemperature: 72-78Â°F\r\nWater Parameters: sg 1.020-1.025; pH 8.1-8.3; dKH 8-12\r\nCare Level: Difficult\r\nTank Size: 50+ Gallons\r\nScientific Name: Chaetodon rostratus\r\nEnvironment: Marine', 'The distinctly yellow-orange striped Copperband Butterflyfish uses its narrow snout and mouth to pick food out of crevices and cracks. It should be noted that the Chaetodon rostratus does best as the only butterflyfish, and in peaceful community tanks. In a reef tank, the Copperband Butterflyfish may pick on anemones, feather dusters, some soft corals, some large-polyped stony corals, and zoanthids. This fish also works great to control the pesty glass anemone, which are also known as aiptasia.', '2015-04-27', 10, 1300, 'accept', 'JFCW5M0', '1137131C.jpg'),
(60, 3, 78, 0, 'Temperament: Semi-aggressive\r\nReef Safe: Yes\r\nFamily: Acanthuridae\r\nNative To: Maldives, Sri Lanka\r\nDiet: Herbivore\r\nAdult Size: Up to 9"\r\nTemperature: 72 - 78Â°F\r\nWater Parameters: sg 1.020-1.026; pH 8.1-8.4; dKH 8-12\r\nCare Level: Moderate\r\nTank Size: 55+ gallons\r\nScientific Name: Acanthurus leucosternon\r\nEnvironment: Marine', 'Tangs are often called surgeon fish because of the scalpel-like spine at the base of its tail.  The usually solitary and territorial tang will swing its tail at a target as a means of defense. The Powder Blue Tang is prized for its vibrant coloring and bold markings, with varying shades of blue accented by yellow and white. A tank with rocks and decor to provide several hiding spots and plenty of swimming space is recommended. Tangs tend to be most aggressive towards fish of similar form and color. To minimize aggression in a small aquarium it is recommended to have only one Tang.', '2015-04-27', 10, 4700, 'accept', 'S5UJVA8', '1033387C.jpg'),
(61, 3, 79, 0, 'Temperament: Semi-aggressive\r\nReef Safe: Yes\r\nFamily: Acanthuridae\r\nNative To: Red Sea\r\nDiet: Herbivore\r\nAdult Size: Up to 10"\r\nTemperature: 72 - 78Â°F\r\nWater Parameters: sg 1.020-1.026; pH 8.1-8.4; dKH 8-12\r\nCare Level: Easy\r\nTank Size: 55+ gallons\r\nScientific Name: Zebrasoma xanthurum\r\nEnvironment: Marine', 'Tangs are also called surgeon fish because of the scalpel-like spine at the base of its tail. The tang will swing its tail as a means of defense. The Red Sea Purple Tang is a majestic blue-ish purple color with a striking yellow tail and yellow accents on the pectoral fins. The Purple Tang is a herbivore, and should be provided with a varied diet that includes frozen and flake foods for herbivores as well as dried algae sheets.\r\n\r\nLiving Environment\r\nA fish tank with ive rock and decor to provide several hiding spots and plenty of swimming space is recommended. Purple Tangs are most aggressive towards fish of similar form, especially other fish in the Zebrasoma genus. To minimize aggression in a small aquarium it is recommended to have only one Tang. The Purple Tang may chase fish with similar feeding behavior or shape, but typically gets along well in a larger community based fish tank.', '2015-04-27', 10, 8300, 'accept', 'S3ZC6QY', '1033522C.jpg'),
(62, 3, 80, 0, 'Temperament: Semi-aggressive\r\nReef Safe: With Caution\r\nFamily: Pomacanthidae\r\nNative To: Indo Pacific: Maldives & Sri Lanka to Indonesia and Palau\r\nDiet: Omnivore\r\nAdult Size: Up to 15"\r\nTemperature: 72 - 78Â°F\r\nWater Parameters: sg 1.023-1.025; pH 8.1-8.4\r\nCare Level: Moderate\r\nTank Size: 100+ gallons\r\nScientific Name: Pomacanthus xanthometopon\r\nEnvironment: Marine', 'Also known as the Yellowmask Angelfish, Yellowface Angelfish, Poisson-ange Ã  front jaune (Maldives - French), Kukuraa kokaa (Maldives - Maldivian), Paru-parang dagat (Philippines), Adeyakko (Japan) and Taring pelandok (Malaysia)\r\n\r\nGive your saltwater aquarium a dash of color by adding a Blueface Angel. This bold, beautiful saltwater aquarium fish can be the sapphire jewel of your underwater masterpiece.\r\n\r\nThe Blueface Angel is also known as a Yellowface angelfish. These names come from the fishâ€™s striking colors. Adult Yellowface angelfish sport a bright yellow mask around the eyes surrounded by sapphire blues and blacks. The rest of the adultâ€™s body is usually a mix of pale yellows and blues with a sunny yellow tail and pectoral fins. These bright yellows and electric blues make the Blueface Angel a brilliant addition to your aquarium.\r\n\r\nLike many angelfish, the Blueface changes its coloring as it matures into an adult. The difference between an adult and juvenile is remarkable. A juvenile will display blue, black and white stripes that will eventually change into the bright yellows and blues of the adult.\r\n\r\nAngelfish are solitary, territorial fish that startle easily, especially in a crowded environment. Aquarists need to take care in matching this angelfish with compatible saltwater aquarium fish. It is best that this angelfish be the only angel in the tank. Additionally, these large angelfish enjoy a lot of space, medium to large aquariums are recommended. Angelfish will feel more secure if you provide plenty of live rock so they can have ample hiding spots. If you have a reef tank, know that Angelfish tend to nip at corals and clam mantles.\r\n\r\nThe beauty and delightful coloring of this saltwater aquarium fish makes it a true treasure for your aquarium.', '2015-04-27', 10, 9000, 'accept', 'SROX4EU', '1306855C.jpg'),
(63, 4, 81, 0, 'Scientific Name:  Agapornis taranta\r\nSize:  6.25 to 6.5 inches tall\r\nNative Region:  Eritrea and Ethiopia\r\nLife Expectancy:  10 to 20 years\r\nNoise Level:  Relatively low, one of the least noisy lovebird species\r\nTalk/Trick Ability:  Lovebirds rarely talk, but they can learn to mimic human speech if taught at a very young age. Because this species loves climbing and playing, as well as interacting with their pet bird owners, they can learn to do tricks.\r\n', 'Traits:  The Abyssinian lovebird is highly social and as a pet, is most commonly kept in pairs because of their need for constant companionship and mutual preening. They are a hardy species and come from mountainous regions. They need space to fly, climb and play, and are quite active and need a lot of toys and stimulation to keep them engaged and healthy. This species can be very affectionate when hand-raised, yet if kept singly, it will need a lot of human interaction and time to stay tame. Because there is a limited quantity of these parrots, most are entered into breeding programs.\r\nBehavior/Health Concerns:  Because the Abyssinian lovebird is social, it is thought best to keep them in pairs rather than singly to keep them happy and healthy. Although this species is quieter than many lovebirds, they have been known to call out in the middle of the night when they get upset. Additionally, because the Abyssinian lovebird eats seeds, berries and fruits, such as sycamore figs and juniper berries in the wild, a similar diet, with a higher fat content than other lovebirds, is required for them.', '2015-04-27', 10, 150, 'accept', 'X5KNMWY', 'abyssinian2-lovebird.jpg'),
(64, 4, 85, 0, 'Native To: Asia\r\nAdult Size: 4"\r\nCare Level: Beginner\r\nScientific Name: Lonchura domestica\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 5+ years\r\nEats: Finch food, vegetables and fruit.\r\n', 'Society Finches are exactly what their name implies -- social! These outgoing companions are best kept in pairs or small groups and can easily be housed with zebra finches. They prefer not to be handled, and make great companions for apartment dwellers. Society finches have a quiet, gentle nature and are easy to care for. Although available mainly in shades of brown and white, it is difficult to find society finches that look exactly alike. Since finches enjoy flying, they should have a flight cage that is longer than it is tall. A habitat that is at least 24" x 18" is recommended. Provide a variety of toys and swings in addition to a place for them to bathe. The sweet nature and quiet disposition of society finches make them the perfect companion!', '2015-04-27', 10, 1400, 'accept', 'HMJ6UI4', 'societyFinch_C.jpg'),
(65, 4, 86, 0, 'Native To: Australia\r\nAdult Size: 4"\r\nCare Level: Beginner\r\nScientific Name: Poephila guttata\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 5+ years\r\nEats: Finch food, vegetables and fruit.', 'Zebra Finches are adorable little companions that are best kept in pairs or small groups. They prefer not to be handled, but that does not take away from their appeal! Zebra finches have a quiet, pleasant chirp and are easy to care for. They are available in a number of color mutations and males sport bright, orange cheeks. Since finches enjoy flying, they should have a flight cage that is longer than it is tall. A habitat that is at least 24" x 18" is recommended. Provide a variety of toys and swings in addition to a place for them to bathe. The gentle nature of zebra finches is sure to brighten your day!', '2015-04-27', 7, 700, 'accept', '0VLSQ63', 'zebraFinch_C.jpg'),
(66, 4, 87, 0, 'Native To: Canary Islands\r\nAdult Size: 4-6"\r\nCare Level: Beginner\r\nScientific Name: Serinus canaria domesticus\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 10+ years\r\nEats: Canary food, vegetables and fruits.', 'Canaries have long been a popular pet bird. Canaries date back as early as the 1400s. Throughout history, canary cages have been elaborately designed and created to complement the beauty and song of these birds. Some members of royalty went as far as to design cages from precious metals and gemstones to keep in their palaces. Unlike certain larger birds, canaries are not very people oriented, but prefer the company of other birds. Canaries can be kept in male/female pairs or females can be kept together, but males should be kept seperately. They require a habitat at least 18" x 18" and make great apartment companions. You may find yellow or red factor canaries in Petco stores that will sing their way into your heart!', '2015-04-27', 9, 900, 'accept', 'N9V2UGF', 'yellowCanary_C.jpg'),
(67, 4, 90, 0, 'Native To: South America\r\nAdult Size: 10"\r\nCare Level: Beginner\r\nScientific Name: Pyrrhura molinae\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 20+ years\r\nEats: Pelleted small parrot food, vegetables, and fruit.', 'Green Cheek Conures are very social, affectionate and entertaining. They crave attention, and it is not uncommon to see them rolling on their backs to get your attention. Green Cheek Conures love to play with toys, so be sure to provide them with a variety of options. They require a habitat that is at least 24" x 24". Energetic and charming, Green Cheek Conures are one of the quieter Conures, which makes them great apartment companions. Although not known for their talking ability, this does not deter them from trying to mimic their pet parent. They thrive on frequent human interaction, so be sure to set aside time for your companion each day. Green Cheek Conures are a big personality wrapped in a small package!', '2015-04-27', 10, 11000, 'accept', 'OR02IG5', 'greenCheekConure_C.jpg'),
(68, 4, 91, 0, 'Native To: Southwestern Mexico\r\nAdult Size: 12"\r\nCare Level: Beginner\r\nScientific Name: Aratinga Canicularis\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 25+ years\r\nEats: Pelleted small parrot food, vegetables, and fruit.', 'Half Moon Conures are quiet, intelligent and playful. These are a great choice for apartment dwellers or pet parents looking for a quieter companion compared to other Conures. Half Moon Conures require a habitat that is at least 24" x 24". They enjoy a variety of "people" food in addition to their pelleted diet, so a lot of pet parents find themselves sharing a meal with their companion. Be sure to research which foods are safe for birds though, as some foods are toxic. They love to play with toys and climb around their cage or playgym, but most of all, they love to spend time with their pet parent. These sweet-natured birds are sure to find a place in your heart!', '2015-04-27', 10, 9000, 'accept', '4IVSJ87', 'halfMoonConure_C.jpg'),
(69, 4, 93, 0, 'Native To: South America\r\nAdult Size: 9-11"\r\nCare Level: Intermediate\r\nScientific Name: Myiopsitta monachus\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 20+ years\r\nEats: Pelleted cockatiel food, vegetables, and fruit.', 'Quakers are friendly, intelligent birds with gregarious personalities. In nature, they are found in groups. However, being hand-fed, they now see humans as their family and readily accept you into their group. They thrive on human interaction and are quick to mimic sounds and words. Quakers require a habitat that is at least 30" x 30". Their intelligence requires a lot of mental stimulation to prevent boredom and feather plucking. A variety of toys and daily interaction with their pet parent will keep quakers happy and healthy!', '2015-04-27', 10, 7000, 'accept', '08IJR7M', 'quaker_C.jpg'),
(70, 4, 94, 0, 'Native To: South America\r\nAdult Size: 9"\r\nCare Level: Intermediate\r\nScientific Name: Pionites Leucogaster\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 20+ years\r\nEats: Pelleted small parrot food, vegetables, and fruit.', 'Caiques are some of the most sought-after bird companions. Their beautiful colors match their bright, comical personalities. Their talking ability is limited, but they make up for it with their acrobatics and silly antics. Caiques are cheerful, playful and highly intelligent. They require a habitat that is at least 30" x 30". They enjoy a variety of "people" food, but be sure to research which foods are healthy for birds, as some foods can be toxic to birds. Caiques are known as the jesters of the bird world and live to make their pet parent laugh!', '2015-04-27', 10, 14000, 'accept', 'QV7DRWJ', 'whiteBellyCaique_C.jpg'),
(71, 4, 95, 0, 'Native To: Ecuador, Peru\r\nAdult Size: 5"\r\nCare Level: Intermediate\r\nScientific Name: Forpus coelestis\r\nMost Active During: Daytime (diurnal)\r\nLife Span: 20+ years\r\nEats: Pelleted small parrot food, vegetables, and fruit.\r\n', 'Parrotlets, also known as "pocket parrots," are energetic, spunky and playful. These small birds have huge personalities and are fantastic companions. Highly intelligent, parrotlets can be taught to do tricks and talk. They require a habitat that is 24" x 24" and their smaller voice makes them a great apartment bird. Parrotlets love spending time with their pet parent and enjoy partaking in your daily routine. They are eager to show off their dynamic personality and need a pet parent who is looking for a fun, energetic companion. These birds show you that big things come in little packages!', '2015-04-27', 10, 7500, 'pending', '', 'fancyParrotlet_C.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE IF NOT EXISTS `tbl_subcategory` (
  `subcatid` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `subcategory` varchar(50) NOT NULL,
  PRIMARY KEY (`subcatid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`subcatid`, `catid`, `subcategory`) VALUES
(1, 1, 'Dog-Food'),
(4, 2, 'Cat-Food'),
(5, 3, 'Fish-Food'),
(6, 1, 'Dash'),
(7, 1, 'Labrador Retriever'),
(8, 1, 'German Shepherd'),
(9, 1, 'Beagle'),
(10, 1, 'Golden Retriever'),
(11, 1, 'Bulldog'),
(12, 1, 'Dachshund'),
(13, 1, 'Pug'),
(14, 1, 'Rajapalyam dog'),
(15, 1, 'Boxer'),
(16, 1, 'Rottweiler'),
(17, 1, 'Manchester Terrier'),
(18, 1, 'Tibetan Spaniel'),
(19, 2, 'Abyssinian CAT'),
(20, 2, 'American Bobtail CAT'),
(21, 2, 'Maine Coon'),
(22, 2, 'Persian'),
(23, 0, ''),
(24, 2, 'Siamese'),
(25, 2, 'Birman'),
(26, 2, 'American Shorthair'),
(27, 2, 'California Spangled Cat'),
(28, 2, 'Burmilla'),
(29, 2, 'Ragdoll'),
(30, 3, 'Blue Neon Guppy'),
(31, 0, ''),
(32, 0, ''),
(33, 1, 'Japanese Spitz'),
(37, 1, 'Rhodesian Ridgeback'),
(38, 1, 'Dalmatian'),
(39, 1, 'Pekingese'),
(40, 1, 'Italian Greyhound'),
(41, 1, 'Maltese Dog'),
(42, 1, 'South Russian Ovcharka'),
(43, 1, 'Chihuahua'),
(44, 1, 'Lhasa Apso'),
(45, 1, 'Pembroke Welsh Corgi'),
(46, 1, 'Glen of Imaal Terrier'),
(47, 1, 'Neapolitan Mastiff'),
(48, 1, 'Bichon Frise'),
(49, 1, 'Chinese Crested'),
(50, 1, 'German Pinscher'),
(51, 2, 'Norwegian Forest Cat'),
(52, 2, 'Colorpoint Shorthair'),
(53, 2, 'Persian'),
(54, 3, 'Silver Mono'),
(55, 3, 'Spotted Scat'),
(56, 3, 'Dalmatian Sailfin Molly'),
(57, 3, 'Male Veiltail Betta'),
(58, 3, 'Blue Neon Guppy'),
(59, 3, 'Blue Male Veiltail Betta'),
(60, 3, 'Red Oranda Goldfish'),
(61, 3, 'Male Halfmoon Betta'),
(62, 3, 'Red Fantail Goldfish'),
(63, 3, 'Silver Veiled Angelfish'),
(64, 3, 'Purple Fantail Goldfish'),
(65, 3, 'Red & White Fantail Goldfish'),
(66, 3, 'Tiger Oscar Cichlid'),
(67, 3, 'Blue Male Crowntail Betta'),
(68, 3, 'Elephant Ear Halfmoon Plakat Betta'),
(69, 3, 'Elephant Ear Halfmoon Betta'),
(70, 3, 'Red Male Crowntail Betta'),
(71, 3, 'Calico Oranda Goldfish'),
(72, 3, 'Calico Oranda Goldfish'),
(73, 3, 'Pigeon Blood Discus'),
(74, 3, 'Borneo Sucker'),
(75, 3, 'Black Moor Goldfish'),
(76, 3, 'Red Cap Oranda Goldfish'),
(77, 3, 'Copperband Butterfly'),
(78, 3, 'Powder Blue Tang'),
(79, 3, 'Purple Tang'),
(80, 3, 'Blueface Angel'),
(81, 4, 'Abyssinian Lovebirds'),
(82, 4, 'Black Cap Conure'),
(83, 4, 'Parakeets'),
(84, 4, 'Cockatiel'),
(85, 4, 'Society Finch'),
(86, 4, 'Zebra Finch'),
(87, 4, 'Canaries'),
(88, 4, 'Sun Conure'),
(89, 4, 'Patagonian Conure'),
(90, 4, 'Green Cheek Conure'),
(91, 4, 'Half Moon Conure'),
(92, 4, 'Doves'),
(93, 4, 'Quaker Parakeet'),
(94, 4, 'White Bellied Caique'),
(95, 4, 'Parrotlet'),
(96, 4, 'Senegal Parrot');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
