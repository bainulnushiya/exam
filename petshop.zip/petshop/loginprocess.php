
<?php
session_start();
include 'Query.php';
function encryptIt($q){
                $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
                $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
                return( $qEncoded );
         }
extract($_POST);
   $pwd = encryptIt($password);
echo $qry="select * from tbl_login where username='$username' and password='$pwd'";
$res=setData($qry);
$f=0;
while($row=mysqli_fetch_array($res))
{
$f=1;
$_SESSION['uname']=$row['username'];
$_SESSION['pwd']=$row['password'];
$role=$row['role'];
$_SESSION['lid']=$row['loginid'];


}
if($f==1)
{
if($role=='user')
{
header('location:user/userhome.php');
}
else
{
header('location:admin/adminhome.php');
}
}
else
{
echo "<script>window.onload=function(){alert('Invalid username or password....!');window.location='login.php';}</script>";


}
?>