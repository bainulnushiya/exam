
<?php
include_once "Query.php";

if (!empty($_POST["cid"])) {
  $cid = $_POST["cid"];

  $query = "SELECT * FROM tbl_state WHERE cid = $cid";

  $results = setData( $query);
  ?>
  <option >select state</option>
  
  <?php

  foreach($results as $state){
    ?>

    <option value="<?php echo $state ["stid"]; ?>"> <?php echo $state["state"]; ?></option>

     <?php
}
}
?>
