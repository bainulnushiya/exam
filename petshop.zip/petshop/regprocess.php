<?php
var_dump($_POST);
extract($_POST);
include 'Query.php';
session_start();
function send($sms, $to) {

    $sms = urlencode($sms);
    $token = "1136e58159181f62362eaac6c8ef4e26";
    $sendercode="ESANGM";   
    $url = "http://sms.safechaser.com/httpapi/httpapi?token=".$token."&sender=".$sendercode."&number=".$to.'&route=2&type=1&sms='.$sms;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 50);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $datares = curl_exec($ch);
    curl_close($ch);
    return $datares;
}
function encryptIt($q){
                $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
                $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
                return( $qEncoded );
         }
   $encrypted = encryptIt($pwd);		 
$qry="insert into tbl_login(username,password,role) values('$email','$encrypted','user')";
setData($qry);
$qry="select max(loginid) from tbl_login";
$res=setData($qry);
$row=mysqli_fetch_array($res);
$id=$row[0];
echo $qry="insert into tbl_register(name,cmpname,email,password,address,country,city,contactno,loginid) values('$f_name','$cmpname','$email','$encrypted','$address','$country','$city','$phone','$id')";
setData($qry);
$otp=rand(1000,9999);
$msg="your otp is  " . $otp;
send($msg, $phone);
$_SESSION['otp']=$otp;
header('location:otp.php');
?>