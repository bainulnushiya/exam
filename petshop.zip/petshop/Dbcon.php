<?php
class Dbcon
{
private function getConnection()
{
$con=mysqli_connect("localhost","root","","pet") OR die("Cound not connect the database");
return $con;
}
public function closeCon()
{
mysqli_close($con);
}
public function submitQuery($qry)
{
$result=0;
$con=$this->getConnection();
$result=mysqli_query($con,$qry);
return $result;
}
public function updateQuery($qry)
{
$con=$this->getConnection();
$result=mysqli_query($con,$qry);
}
}
?>
