<script>
function validate()
{
	if (document.myform.npass.value!=document.myform.conpass.value)
	{
	alert("password missmatch");
	//document.getElementById('feedback').focus();
	return false;
	}
return true;
}	
</script>
<?php
session_start();
include 'header.php';
function encryptIt($q){
                $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
                $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
                return( $qEncoded );
         }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
<br />
<form id="f1" method="post" name="myform">
<h1>CHANGE PASSWORD</h1>
<br />
<table width="200" border="0">
  <tr>
    <td>CURRENT PASSWORD<input type="text" name="cpass" />&nbsp;</td>
  </tr>
  <tr>
    <td>NEW PASSWORD<input type="text" name="npass"  /> &nbsp;</td>
  </tr>
   <tr>
    <td>CONFIRM PASSWORD<input type="text" name="conpass" /> &nbsp;</td>
  </tr>
   <tr>
    <td><input type="submit" name="submit" value="change" onclick="return validate()" /> &nbsp;</td>
  </tr>
</table>

</form>
<?php
if(isset($_POST['submit']))
{
extract($_POST);
include '../Query.php';
$lid=$_SESSION['lid'];
$qry="select * from tbl_login where loginid='$lid' and password='$cpass'";
$res=setData($qry);
$row=mysqli_fetch_array($res);
$uid=$row[0];
if(mysqli_num_rows($res)>0)
{
$qry="update tbl_login set password='".encryptIt($conpass)."' where loginid='".$lid."'";
setData($qry);
echo "<script>window.onload=function(){alert('password changed....!');window.location='changepass.php';}</script>";
}
else
{
echo "<script>window.onload=function(){alert('enter correct password....!');window.location='changepass.php';}</script>";	
}
}
?>
</div>
 <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#"><span>Advanced Search</span></a></li>
						<li><a href="#">Orders and Returns</a></li>
						<li><a href="#"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="about.html">About Us</a></li>
						<li><a href="faq.html">Customer Service</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="contact.html"><span>Site Map</span></a></li>
						<li><a href="preview-2.html"><span>Search Terms</span></a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="contact.html">Sign In</a></li>
							<li><a href="index.html">View Cart</a></li>
							<li><a href="#">My Wishlist</a></li>
							<li><a href="#">Track My Order</a></li>
							<li><a href="faq.html">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-123-456789</span></li>
							<li><span>+00-123-000000</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			<div class="copy_right">
				<p>Compant Name © All rights Reseverd | Design by  <a href="http://w3layouts.com">W3Layouts</a> </p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
</body>
</html>


</body>
</html>
