<?php
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {color: #000000; font-size: large; }
.style7 {color: #FFFFFF; font-size: large; font-weight: bold; }
-->
</style>
</head>

<body>
<div align="center">
<table width="1028" border="0" style="border:solid">
  <tr>
    <td height="46" bgcolor="#333333"><span class="style7">Category&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Subcategory&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Brief Description&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Detail Description&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Posted Date&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">No of Items&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Rate&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Image&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7"></span></td>
  </tr>
  <?php
  include '../Query.php';
  $qry="select * from tbl_sale,tbl_category,tbl_subcategory where tbl_sale.catid=tbl_category.catid and tbl_category.catid=tbl_subcategory.catid and tbl_sale.subcatid=tbl_subcategory.subcatid and tbl_sale.status='pending'";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style3"><?php echo $row['category'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['subcategory'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['briefdesc'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['detaildesc'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['posted_date'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['itemcount'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['rate'];?>&nbsp;</span></td>
	 <td><span class="style3"><?php echo $row['image'];?>&nbsp;</span></td>
    <td><span class="style3"><img src="/upload/<?php echo $row['rate'];?>" width="100px" height="100px" />&nbsp;</span></td>
    <td><span class="style3"><a href="acceptad.php?id=<?php echo $row[0];?>">Accept</a>&nbsp;</span></td>
  </tr>
  <?php
  }
  ?>
</table>

</div>
</body>
</html>
