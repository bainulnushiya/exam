<?php
session_start();
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>
<MMString:LoadString id="insertbar/formsButton" />
</title>
<!-- Copyright 2000-2006 Adobe Macromedia Software LLC and its licensors. All rights reserved. -->
<!-- Copyright 2000-2006 Adobe Macromedia Software LLC and its licensors. All rights reserved. -->
<!-- Copyright 2000-2006 Adobe Macromedia Software LLC and its licensors. All rights reserved. -->
</head>

<body>
<div align="center">
<table width="594" style="border:solid" border="1">
<tr><td width="315" height="44">Item</td>
<td width="142">Image</td>
</tr>
<?php
$userid=$_SESSION['lid'];
include '../Query.php';
$qry="select * from tbl_sale,tbl_cart where tbl_cart.productid=tbl_sale.saleid and tbl_cart.userid='$userid'";
$res=setData($qry);
while($row=mysqli_fetch_array($res))
{
?>
<tr>
<td><?php echo $row['detaildesc'];?></td>
<td><img src="../upload/<?php echo $row['image'];?>" width="135" height="169" />
<td width="121"><a href="cartbuy.php?id=<?php echo $row['saleid'];?>">Buy now</a></td>
</tr>
<?php
}
?>
</table>


<table width="594" style="border:solid" border="1">
<tr><td width="315" height="44">Item</td>
<td width="142">Image</td>
</tr>
<?php
//$userid=$_SESSION['lid'];
//include '../Query.php';
$qry1="select * from tbl_product,tbl_cart where tbl_cart.productid=tbl_product.productid and tbl_cart.userid='$userid'";
$res1=setData($qry1);
while($row1=mysqli_fetch_array($res1))
{
?>
<tr>
<td><?php echo $row1['description'];?></td>
<td><img src="../upload/<?php echo $row1['image'];?>" width="135" height="169" />
<td width="121"><a href="cartbuy2.php?id=<?php echo $row1['productid'];?>">Buy now</a></td>
</tr>
<?php
}
?>
</table>


</div>

</body>
</html>
