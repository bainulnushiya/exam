<?php
session_start();	
include 'header.php';
                        include '../Query.php';

						$uname		=	$_SESSION['uname'];
						$qry	=	"Select * from tbl_register where email='$uname'";
				        $res=setData($qry);
						$row=mysqli_fetch_array($res);
					?>
                    <?php
			  if(isset($_POST['submit']))
			  {
				  $name=$_POST["name"];
				  $email=$_POST["email"];
				  $address=$_POST["address"];
				  $country=$_POST["country"];
				  $city=$_POST["city"];
					$id=$_POST['id'];
				  $contactno=$_POST["contactno"];
				
				   $qry=("update tbl_register set name='".$name."',email='".$email."',address='".$address."',country='".$country."',city='".$city."',contactno='".$contactno."' where regid=".$id);
				   $result=update_Data($qry);
					 echo "<script>alert('data updated Successful.')</script>";

				  /*echo $sql1;*/
				  /*echo "<script>window.location='myaccount.php'</script>";*/

			  }
			  ?>
				<script type="text/javascript">
				/*function check_email(){

				var email = $("#email").val();
				//alert("");

				if(email.length > 2){
				$('#Loading').show();
				//alert("haii");
				$.post("autocomplete.php", {
				email: $('#email').val(),
				}, function(response){
				$('#Info').fadeOut();
				$('#Loading').hide();
				setTimeout("finishAjax('Info', '"+escape(response)+"')", 450);
				});
				return false;
				}
				}
				function finishAjax(id, response){
				$('#'+id).html(unescape(response));
				$('#'+id).fadeIn(1000);

				}*/


				</script>
				</head>



					<div class="wrapper">
                    <link href="style.css" rel="stylesheet" type="text/css" />

        <div class="innerpage_content">
        	<div class="page_title">Edit Profile</div>
            <!--<div class="page_banner"><img src="images/pbanner.jpg" /></div>-->
            <div class="page_content"><p>
            	<div class="my_left">
                	<ul>
                    	<li><a href="edit_profile.php">EDIT PROFILE</a></li>
                        <li><a href="edit_password.php">CHANGE PASSWORD</a></li>
                        <li><a href="step1.php">TAKE TEST</a></li>

                    </ul>
                </div>
                <div class="my_right">

                 <form name="myForm" action="#" onsubmit="return validateForm();" method="post">
                	<table height="536">
<tr>
                        	<td>Name</td>
                            <td><input type="text" name="name"  id="name"  onchange="fname()"   value="<?php echo $row['name'] ?>" required /></td>
                        </tr>
                        <tr>
                        	<td>email</td>
													<td><input type="text" name="email" id="age"  size="35" onchange="agee()" value="<?php echo $row['email'] ?>" required /></td>

                          </tr>
                         <tr>
                        	<td>Address</td>
                            <td><textarea name="address" id="case"  onchange="casee()"><?php echo $row['address'] ?></textarea></td>
                        </tr>
                        <tr>
                        	<td>Country</td>
                            <td><textarea name="country" id="case"  onchange="casee()"><?php echo $row['country'] ?></textarea></td>
                        </tr>

                        <tr>
                        	<td>City</td>
                            <td><input type="text" name="city"    id="city"  onchange="cityy()"  value="<?php echo $row['city'] ?>" /></td>
                        </tr>
												
                        </tr>
                       
                        	<td>Phone</td>
                            <td><input type="text" name="contactno"  id="contactno"  value="<?php echo $row['contactno'] ?>"value="" pattern="[789][0-9]{9}" title=" use valid Mobile number" required/></td>
							<input type="hidden" name="id" value="<?php echo $row['regid'] ?>">
							</tr>

                        <tr>
                        	<td></td>
                            <td><input type="submit" name="submit" value="submit" class="btn" /></td>
                        </tr>
                    </table>
										<script src="jquery-3.2.1.min.js"></script>
								    <script src="js/validation.js"></script>
              </form>
							<script src="jquery-3.2.1.min.js"></script>
							<script src="js/validation.js"></script>
              </div>
            </p></div>
        </div>

    </div>
