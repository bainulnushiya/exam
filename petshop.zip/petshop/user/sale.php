<script>
function validate()
{
	if(document.getElementById('cat').value==0)
	{
	alert("**select category**");
	return false;
	}
	if(document.getElementById('subcat').value==0)
	{
	alert("**select subcategory**");
	return false;
	}
	if(document.getElementById('briefdesc').value=="")
	{
	alert("please fill this field");
	document.getElementById('briefdesc').focus();
	return false;
	}
	if(document.getElementById('detaildesc').value=="")
	{
	alert("please fill this field");
	document.getElementById('detaildesc').focus();
	return false;
	}
	if(document.getElementById('item').value=="")
	{
    alert("Number must be filled out");
	document.getElementById('item').focus();
    return false;
	}
	if(document.getElementById('rate').value=="")
	{
    alert("Rate must be filled out");
	document.getElementById('rate').focus();
    return false;
	}
return true;
}
</script>
<?php
session_start();
include 'header.php';
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="ajax.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: large}
.style3 {font-size: large; font-weight: bold; }
-->
</style>
</head>

<body>
<div align="center">
<form method="post" enctype="multipart/form-data">
<table width="522" height="446" border="0">
  <tr>
    <td width="156"><span class="style3">Category</span></td>
    <td width="218"><span class="style3">
      <select name="cat" id="cat" onChange="getSub(this.value)">
        <option value="0">---Select---</option>
        <?php
	include '../Query.php';
	$qry="select * from tbl_category";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
      &nbsp;</span></td>
  </tr>
  <tr>
    <td colspan="2"><div id="sub"></div></td>
  </tr>
  <tr>
    <td><span class="style3">Brief Description</span></td>
    <td>
      <textarea name="briefdesc" id="briefdesc"></textarea>      &nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">Detail Description</span></td>
    <td>
      <textarea name="detaildesc" id="detaildesc"></textarea>      &nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">No of Items</span></td>
    <td>
      <input type="number" min="1" max="10" name="item" id="item" />      &nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">Rate</span></td>
    <td>
      <input type="text" name="rate" id="rate"/>      &nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">Image</span></td>
    <td>
      <input type="file" name="image" required />      &nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><div align="center"><span class="style1"><span class="style1">
      <input type="submit" name="submit" value="Submit" onClick="return validate()" />
    </span></span></div></td>
    </tr>
</table>
</form>
<?php
if(isset($_POST['submit']))
{
$da=date('Y-m-d');
$y=$_FILES['image']['name'];
$r=$_FILES['image']['tmp_name'];		
move_uploaded_file($r,"../upload/".$y);
$lid=$_SESSION['lid'];
$qry="select * from tbl_register where loginid='$lid'";
$res=setData($qry);
$row=mysqli_fetch_array($res);
$uid=$row[0];
extract($_POST);
$qry="insert into tbl_sale(catid,subcatid,userid,briefdesc,detaildesc,posted_date,itemcount,rate,status,image) values('$cat','$subcat','$uid','$briefdesc','$detaildesc','$da','$item','$rate','pending','$y')";
$res=setData($qry);
echo "<script>window.onload=function(){alert('Post added....!');window.location='sale.php';}</script>";
}
?>
</div>
 <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#"><span>Advanced Search</span></a></li>
						<li><a href="#">Orders and Returns</a></li>
						<li><a href="#"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="about.html">About Us</a></li>
						<li><a href="faq.html">Customer Service</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="contact.html"><span>Site Map</span></a></li>
						<li><a href="preview-2.html"><span>Search Terms</span></a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="contact.html">Sign In</a></li>
							<li><a href="index.html">View Cart</a></li>
							<li><a href="#">My Wishlist</a></li>
							<li><a href="#">Track My Order</a></li>
							<li><a href="faq.html">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-123-456789</span></li>
							<li><span>+00-123-000000</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			<div class="copy_right">
				<p>Compant Name © All rights Reseverd | Design by  <a href="http://w3layouts.com">W3Layouts</a> </p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
</body>
</html>


</body>
</html>
