<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<head>
<title>Pet Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="../admin/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../admin/css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="../admin/js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="../admin/js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="../admin/js/nav.js"></script>
<script type="text/javascript" src="../admin/js/move-top.js"></script>
<script type="text/javascript" src="../admin/js/easing.js"></script>
<script type="text/javascript" src="../admin/js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
</head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="header_top">
			<div class="logo">
				<a href="../admin/index.html"><img src="../admin/images/logo.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form>
				    	<input type="text" value="Search for Products" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
				    </form>
			    </div>
			   <div class="login">
		   	   <span><a href="../admin/login.php"><img src="../admin/images/login.png" alt="" title="login"/></a></span>
		   </div>
	   
		     <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
		 </div>
		  <div class="currency" title="currency">
					
		    <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
   </div>
		   
		 <div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		 <li><a href="userhome.php">Home</a></li>
       
  <li><a href="#">Manage Sale</a>
    <ul>
      <li><a href="sale.php">Post Ad</a></li>
      <li><a href="viewsale.php">View Ads</a></li>
      
    </ul>
  </li>
 <li><a href="#">Buy Products</a>
    <ul>
      <li><a href="products.php">User Added</a></li>
      <li><a href="products1.php">Admin Added</a></li>
      
    </ul>
  </li>

 <li><a href="cartview.php">View Cart</a></li>
  <li><a href="feedback.php">Feedback</a></li>
  <li><a href="changepass.php">Change<br>password</a></li>
  <li><a href="../index.php">Logout</a> </li>
  <div class="clear"></div>
</ul>
</div>
	<div class="header_bottom">
		<div class="header_bottom_left">
				
				
	  </div>
			<div class="section group">
							
				
			</div>
		  <div class="clear"></div>
	</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
</div>	
</div>
</div>

    </div>
   
							  
</html>

