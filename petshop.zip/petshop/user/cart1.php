``																																																																																												`	`																																																																		`<?php
include '../Query.php';
$pid=$_REQUEST['id'];
$uid=$_REQUEST['uid'];
$da=date('Y-m-d');
$qry="select * from tbl_cart where userid='$uid' and productid='$pid'";
$res=setData($qry);
if(mysqli_num_rows($res)>0)
{
echo "<script>window.onload=function(){alert('Product already added');window.location='products1.php';}</script>";
}
else
{
$qry="insert into tbl_cart(userid,productid,saveddate) values('$uid','$pid','$da')";
$res=setData($qry);
echo "<script>window.onload=function(){alert('Product added to cart');window.location='products1.php';}</script>";
}
?>