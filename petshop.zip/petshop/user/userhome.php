<?php
session_start();
$uid=$_SESSION['lid'];
?>
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<head>
<title>Pet Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="../js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="../js/nav.js"></script>
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
<script type="text/javascript" src="../js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
<style type="text/css">
<!--
body,td,th {
	font-family: Times New Roman, Times, serif;
	font-weight: bold;
}
a {
	font-family: Times New Roman, Times, serif;
	font-weight: bold;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Times New Roman, Times, serif;
	font-weight: bold;
}
-->
</style></head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="header_top">
			<div class="logo">
				<a href="../index.html"><img src="../images/logo.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form>
				    	<input type="text" value="Search for Products" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
				    </form>
			    </div>
			   <div class="login">
		   	   <span><a href="../login.php"><img src="../images/login.png" alt="" title="login"/></a></span>
		   </div>
	   
		     <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
		 </div>
			<div class="currency" title="currency">
					
					 <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
   </div>
		   
		 <div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		<li><a href="userhome.php">Home</a></li>
       
  <li><a href="#">Manage Sale</a>
    <ul>
      <li><a href="sale.php">Post Ad</a></li>
      <li><a href="viewsale.php">View Ads</a></li>
      
    </ul>
  </li>
 <li><a href="#">Buy Products</a>
    <ul>
      <li><a href="products.php">User Added</a></li>
      <li><a href="products1.php">Admin Added</a></li>
      
    </ul>
  </li>

 <li><a href="cartview.php">Cart</a></li>
 <li><a href="changepass.php">Change password</a></li>
 <li><a href="myact.php">My Acconut</a></li>
 
  <li><a href="feedback.php">Feedback</a></li>
   <li><a href="../index.php">Logout</a> </li>
  <div class="clear"></div>
</ul>
</div>
	<div class="header_bottom">
	
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="../images/1.jpg" alt=""/></li>
					  <li><img src="../images/2.jpg" alt=""/></li>
                      <li><img src="../images/3.jpg" alt=""/></li>
                        <li><img src="../images/5.jpg" alt=""/></li>
					  <li><img src="../images/6.jpg" alt=""/></li>
						<li><img src="../images/7.jpg" alt=""/></li>
						<li><img src="../images/8.jpg" alt=""/></li>
                        <li><img src="../images/9.jpg" alt=""/></li>
				    </ul>
			    </div>
	      </section>
<!-- FlexSlider -->

	    </div>
	  <div class="clear"></div>
      	<div class="header_bottom_left">
			<div class="section group">
            
		  
          <?php
			include '../Query.php';
  $qry="select * from tbl_product,tbl_category,tbl_subcategory where tbl_product.catid=tbl_category.catid and tbl_product.subcatid=tbl_subcategory.subcatid and tbl_category.catid=tbl_subcategory.catid limit 1";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
			?>
					<div class="listimg listimg_2_of_1">
						
					</div>
				    <div class="text list_2_of_1">
						
						
				   </div>
                   <?php
				   }
				   ?>
			  			
			
    		</div>
				<div class="heading">
    		<h3> previous search products</h3>
    		</div>
			<div class="section group">
            
		  			
				
                <?php
				//$qry="select * from tbl_product,tbl_category,tbl_subcategory where tbl_product.catid=tbl_category.catid and tbl_product.subcatid=tbl_subcategory.subcatid and tbl_category.catid=tbl_subcategory.catid and tbl_product.productid=5";
			
  $qry=" select * from tbl_wishlist where uid=$uid";
 // echo $qry;
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
	  $prod=$row['productid'];
	  //echo $prod;
	  $qry6=" select * from tbl_sale where saleid=$prod";
		//echo $qry6;
	  $res6=setData($qry6);
  while($row6=mysqli_fetch_array($res6))
  {
	  $subcatid = $row6['subcatid'];
	  $qry8=" select * from tbl_subcategory where subcatid='$subcatid'";
		//echo $qry6;
	  $res8=setData($qry8);
	  $row8=mysqli_fetch_array($res8);
			?>
					<div class="listimg listimg_2_of_1"><br>
						 <a href="../preview.html"> <img src="../upload/<?php echo $row6['image'];?>" width="150" height="150" alt="" /></a>
					<!--</div>
				    <div class="text list_2_of_1">-->
						<h2><?php echo $row8['subcategory'];?></h2>
						<p><?php echo $row6['rate'];?></p>
						<div class="button"><span><a href="cart.php?id=<?php echo $row[0];?>&uid=<?php echo $uid;?>">Add to cart</a></span></div>
				   </div>
                   <?php
				   }
  }
				   ?>
			   </div>	
			   <div class="section group">
            
		  			
				
                <?php
				//$qry="select * from tbl_product,tbl_category,tbl_subcategory where tbl_product.catid=tbl_category.catid and tbl_product.subcatid=tbl_subcategory.subcatid and tbl_category.catid=tbl_subcategory.catid and tbl_product.productid=5";
			
  $qry=" select * from tbl_wishlist where uid=$uid";
 // echo $qry;
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
	  $prod=$row['productid'];
	  //echo $prod;
	  $qry7=" select * from tbl_product where productid=$prod";
		//echo $qry6;
	  $res7=setData($qry7);
  while($row6=mysqli_fetch_array($res7))
  {
			?>
					<br><div class="listimg listimg_2_of_1">
						 <a href="../preview.html"> <img src="../upload/<?php echo $row6['image'];?>" width="150" height="150" alt="" /></a>
					<!--</div>
				    <div class="text list_2_of_1">-->
						<h2><?php echo $row6['title'];?></h2>
						<p><?php echo $row6['rate'];?></p>
						<div class="button"><span><a href="cart.php?id=<?php echo $row[0];?>&uid=<?php echo $uid;?>">Add to cart</a></span></div>
				   </div>
                   <?php
				   }
  }
				   ?>
			   </div>	
			</div><br>
		  <div class="clear"></div>
		</div>
  </div>	
</div>
  </div>
  		  <div class="clear"></div>

<div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#"><span>Advanced Search</span></a></li>
						<li><a href="#"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="../about.html">About Us</a></li>
						<li><a href="../faq.html">Customer Service</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="../contact.html">Sign In</a></li>
							<li><a href="../scartview.php">View Cart</a></li>
					        <li><a href="../faq.html">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-123-456789</span></li>
							<li><span>+00-123-000000</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			<div class="copy_right">
				<p>Compant Name © All rights Reseverd | Design by  <a href="http://w3layouts.com">W3Layouts</a> </p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="../css/flexslider.css" rel='stylesheet' type='text/css' />
							  <script defer src="../js/jquery.flexslider.js"></script>
							  <script type="text/javascript">
								$(function(){
								  SyntaxHighlighter.all();
								});
								$(window).load(function(){
								  $('.flexslider').flexslider({
									animation: "slide",
									start: function(slider){
									  $('body').removeClass('loading');
									}
								  });
								});
							  </script>
</body>
</html>

