
<?php
session_start();
include 'header.php';
?>
<script>
function validate()
{
	if(document.getElementById('bank').value==0)
	{
	alert("**select category**");
	return false;
	}
	if(document.getElementById('ccno').value=="")
	{
    alert("Number must be filled out");
	document.getElementById('ccno').focus();
    return false;
	}

	if(document.getElementById('ccname').value=="")
	{
	alert("please fill this field");
	document.getElementById('ccname').focus();
	return false;
	}
	if(document.getElementById('expdate').value=="")
	{
	alert("please fill this field");
	document.getElementById('expdate').focus();
	return false;
	}
	
	if(document.getElementById('amount').value=="")
	{
    alert("Rate must be filled out");
	document.getElementById('amount').focus();
    return false;
	}
return true;
}
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: large}
.style3 {font-size: large; font-weight: bold; }
-->
</style>
</head>

<body>
<?php
$id=$_REQUEST['id'];
include '../Query.php';
		//$id=$_REQUEST['id'];
		 //$qry="select * from tbl_sale,tbl_category,tbl_subcategory where tbl_sale.catid=tbl_category.catid and tbl_category.catid=tbl_subcategory.catid and tbl_sale.subcatid=tbl_subcategory.subcatid and tbl_sale.status='accept' and tbl_sale.saleid='$id'";
		 // $res=setData($qry);
		 // while($row=mysqli_fetch_array($res))
		 // {
		 // $amt=$row['rate'];
		 // $pid=$row[0];
		 // }
?>
<div align="center">
<form method="post">
<h1>Enter your credit card details</h1>
<table width="591" height="336" border="0">
  <tr>
    <td><span class="style3">Select Bank&nbsp;</span></td>
    <td><span class="style3">
      <select name="bank"id="bank">
          <option value="0">---Select---</option>
          <option value="SBI">SBI</option>
           <option value="SBT">SBT</option>
        </select>
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style3">Enter Credit card number&nbsp;</span></td>
    <td><span class="style3">
      <input type="text" name="ccno" id"ccno" />
      &nbsp;</span></td>
  </tr>
  <tr>
    <td><span class="style3">Credit card name</span></td>
    <td><input type="text" name="ccname" id"ccname" />&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">Expiry date</span></td>
    <td><input type="date" name="expdate" id="expdate"/>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style3">Total Amount</span></td>
    <td><input type="text" name="amount" id="amount"  value="<?php echo $id;?>" readonly="readonly"/>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><div align="center"><input type="submit" name="submit" value="Proceed to payment" onClick="return validate()"/></div></td>
    </tr>
</table>
</form>
<?php
if(isset($_POST['submit']))
{
extract($_POST);
$lid=$_SESSION['lid'];
$qry="select * from tbl_register where loginid='$lid'";
$res=setData($qry);
$row=mysqli_fetch_array($res);
$uid=$row[0];
$qry="insert into tbl_payment(userid,saleid,bank,ccno,ccname,expdate) values('$uid','$id','$bank','$ccno','$ccname','$expdate')";
setData($qry);
$qry1="UPDATE `tbl_sale` SET `status`='saled' where saleid=$id ";
setData($qry1);
echo $qry1;
echo "<script>window.onload=function(){alert('Payment complete....!');window.location='products.php';}</script>";
}
?>
</div>
</body>
</html>
