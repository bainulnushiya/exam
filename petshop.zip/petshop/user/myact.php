<?php
session_start();	
include 'header.php';

                include '../Query.php';
				
				$id		=	$_SESSION['uname'];
				
				
		
				$con1	=	"Select * from tbl_register where email='$id'";
				
				$res    =   setData($con1);
				$row	=	mysqli_fetch_array($res);

					echo "<script>alert(values are Successful updated);</script>";?>




          <link href="style.css" rel="stylesheet" type="text/css" />


            <div class="wrapper">
<link href="style.css" rel="stylesheet" type="text/css" />


    <div class="wrapper">

        <div class="innerpage_content">
        	
            <!--<div class="page_banner"><img src="images/pbanner.jpg" /></div>-->
            <div class="page_content"><p>
            	<div class="my_left">
                	<ul>
                    	<li><a href="editprof.php">EDIT PROFILE</a></li>
                        <li><a href="changepass.php">CHANGE PASSWORD</a></li>
                     

                    </ul>
                </div>
                <div class="my_right">

                <table width="610" height="536" style="margin-left:30px;" cellpadding="0" cellspacing="0">
<tr>
                        	<td width="135">Name</td>
            <td width="253"><?php echo $row['name']; ?></td>
                  </tr>
                        <tr>
                        	<td>Email</td>
                            <td width="10"><?php echo $row['email']; ?></td>
                  </tr>
                        <tr>
                        	<td>address</td>
                            <td><?php echo $row['address']; ?></td>
                        </tr>
                        <tr>
                        	<td>Country</td>
                            <td><?php echo $row['country']; ?></td>
                        </tr>

                        <tr>
                        	<td>City</td>
                            <td><?php echo $row['city']; ?></td>
                        </tr>
                        <tr>
                        	<td>Contactno</td>
                            <td><?php echo $row['contactno']; ?></td>
                        </tr>
                        
                        



                    </table>
              </div>
            </p></div>
        </div>

    </div>
