<?php
session_start();
include 'header.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style3 {color: #000000; font-size: large; }
.style7 {color: #FFFFFF; font-size: large; font-weight: bold; }
-->
</style>
</head>

<body>
<div align="center">
<table width="1028" border="0" style="border:solid">
  <tr>
    <td height="46" bgcolor="#333333"><span class="style7">Category&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Subcategory&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Brief Description&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Detail Description&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Posted Date&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">No of Items&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Rate&nbsp;</span></td>
    <td bgcolor="#333333"><span class="style7">Image&nbsp;</span></td>
    
  </tr>
  <?php
  include '../Query.php';
  $lid=$_SESSION['lid'];
$qry="select * from tbl_register where loginid='$lid'";
$res=setData($qry);
$row=mysqli_fetch_array($res);
$uid=$row[0];
  $qry="select * from tbl_sale,tbl_category,tbl_subcategory where tbl_sale.catid=tbl_category.catid and tbl_category.catid=tbl_subcategory.catid and tbl_sale.subcatid=tbl_subcategory.subcatid and tbl_sale.status='accept' and tbl_sale.userid='$uid'";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><span class="style3"><?php echo $row['category'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['subcategory'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['briefdesc'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['detaildesc'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['posted_date'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['itemcount'];?>&nbsp;</span></td>
    <td><span class="style3"><?php echo $row['rate'];?>&nbsp;</span></td>
    <td><span class="style3"><img src="../upload/<?php echo $row['image'];?>" width="100px" height="100px" />&nbsp;</span></td>
   
  </tr>
  <?php
  }
  ?>
</table>

</div>
 <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Customer Service</a></li>
						<li><a href="#"><span>Advanced Search</span></a></li>
						<li><a href="#">Orders and Returns</a></li>
						<li><a href="#"><span>Contact Us</span></a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why buy from us</h4>
						<ul>
						<li><a href="about.html">About Us</a></li>
						<li><a href="faq.html">Customer Service</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="contact.html"><span>Site Map</span></a></li>
						<li><a href="preview-2.html"><span>Search Terms</span></a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>My account</h4>
						<ul>
							<li><a href="contact.html">Sign In</a></li>
							<li><a href="index.html">View Cart</a></li>
							<li><a href="#">My Wishlist</a></li>
							<li><a href="#">Track My Order</a></li>
							<li><a href="faq.html">Help</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+91-123-456789</span></li>
							<li><span>+00-123-000000</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			<div class="copy_right">
				<p>Compant Name © All rights Reseverd | Design by  <a href="http://w3layouts.com">W3Layouts</a> </p>
		   </div>
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
</body>
</html>


</body>
</html>
